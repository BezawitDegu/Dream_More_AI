# backend/workers/embeding_worker.py
# Embedding worker — chunks text and stores embeddings in ChromaDB.
# Can be called directly or from a queue for async processing.

from backend.ai.rag_pipeline import chunk_resume_text, store_resume_chunks
from backend.repositories.resume_repository import update_resume_status


def run_embedding_job(resume_id: str, text: str) -> dict:
    """
    Full embedding pipeline for a single resume:
      1. Chunk the text into 300-char overlapping segments
      2. Embed each chunk via nomic-embed-text (local Ollama)
      3. Upsert embeddings into ChromaDB

    Returns result dict. Never raises — errors are caught and returned.
    """
    try:
        update_resume_status(resume_id, "indexing")

        chunks = chunk_resume_text(text, resume_id)
        if not chunks:
            update_resume_status(resume_id, "error")
            return {"error": "No text chunks generated — resume text may be empty."}

        store_resume_chunks(chunks)
        update_resume_status(resume_id, "ready")

        return {
            "resume_id": resume_id,
            "chunks":    len(chunks),
            "status":    "ready",
        }
    except Exception as e:
        update_resume_status(resume_id, "error")
        return {"error": f"Embedding worker failed: {e}"}
