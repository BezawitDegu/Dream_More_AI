# backend/workers/analysis_worker.py
# Analysis worker — runs the full RAG → LLM → score → report pipeline.
# Called directly from the controller or from a queue for async processing.

from backend.ai.rag_pipeline import retrieve_resume_chunks
from backend.ai.prompt_builder import build_resume_prompt
from backend.ai.ollama_client import run_analysis
from backend.ai.scoring import extract_scores_from_analysis, score_label
from backend.ai.report_generator import generate_report
from backend.storage.report_storage import save_report
from backend.repositories.resume_repository import update_resume_status


def run_analysis_job(resume_id: str) -> dict:
    """
    Full analysis pipeline for one resume:
      1. Retrieve top-8 chunks from ChromaDB (RAG)
      2. Build an ATS analysis prompt
      3. Run LLaMA3 locally via Ollama
      4. Compute weighted composite score
      5. Save the report to /reports/

    Returns a result dict. Never raises — errors are returned as dicts.
    """
    try:
        update_resume_status(resume_id, "analysing")

        # ── RAG retrieval ──────────────────────────────────────────────────
        chunks = retrieve_resume_chunks(
            query="skills experience education projects summary",
            top_k=2,
            resume_id=resume_id,
        )
        if not chunks:
            update_resume_status(resume_id, "error")
            return {"error": "No indexed data found. Please re-upload the resume."}

        # ── LLM analysis ───────────────────────────────────────────────────
        prompt   = build_resume_prompt(chunks, analysis_type="ATS")
        analysis = run_analysis(prompt)

        if "error" in analysis:
            update_resume_status(resume_id, "error")
            return analysis

        # ── Score + report ─────────────────────────────────────────────────
        score       = extract_scores_from_analysis(analysis)
        label       = score_label(score)
        report_json = generate_report(resume_id, analysis, score)
        save_report(resume_id, report_json)
        update_resume_status(resume_id, "done", score=score)

        return {
            "resume_id": resume_id,
            "score":     score,
            "label":     label,
            "analysis":  analysis,
        }

    except Exception as e:
        update_resume_status(resume_id, "error")
        return {"error": f"Analysis worker failed: {e}"}
