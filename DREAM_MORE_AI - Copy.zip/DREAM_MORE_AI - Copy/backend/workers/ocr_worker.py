# backend/workers/ocr_worker.py
# OCR fallback for scanned / image-based PDFs.
# Uses pytesseract + Tesseract (local install). Gracefully skips if unavailable.

import fitz          # PyMuPDF
from PIL import Image


def _tesseract_available() -> bool:
    """Return True if pytesseract + Tesseract binary are both installed."""
    try:
        import pytesseract
        pytesseract.get_tesseract_version()
        return True
    except Exception:
        return False


def needs_ocr(pdf_bytes: bytes, min_chars: int = 50) -> bool:
    """
    Return True if the PDF contains less than min_chars of selectable text,
    meaning it is likely a scanned image that needs OCR.
    """
    try:
        pdf   = fitz.open(stream=pdf_bytes, filetype="pdf")
        total = sum(len(page.get_text()) for page in pdf)
        pdf.close()
        return total < min_chars
    except Exception:
        return False


def extract_text_with_ocr(pdf_bytes: bytes, dpi: int = 200) -> str:
    """
    Rasterise every PDF page and extract text with Tesseract OCR.
    Returns empty string if Tesseract is not installed.
    """
    if not _tesseract_available():
        print(
            "⚠️  Tesseract not found — OCR unavailable.\n"
            "    Install Tesseract: https://github.com/tesseract-ocr/tesseract\n"
            "    Then: pip install pytesseract"
        )
        return ""

    import pytesseract

    try:
        pdf  = fitz.open(stream=pdf_bytes, filetype="pdf")
        text = ""
        for page in pdf:
            pix = page.get_pixmap(dpi=dpi)
            img = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            text += pytesseract.image_to_string(img) + "\n"
        pdf.close()
        return text.strip()
    except Exception as e:
        print(f"⚠️  OCR error: {e}")
        return ""
