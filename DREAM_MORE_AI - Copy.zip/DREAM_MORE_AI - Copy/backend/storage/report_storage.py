# backend/storage/report_storage.py
# Saves and loads analysis reports from /reports on the local filesystem.

from typing import Optional
import json
from pathlib import Path

from backend.config.settings import REPORT_OUTPUT_DIR


def save_report(resume_id: str, report_json: str) -> Path:
    """Write a JSON report string to /reports/<resume_id>_report.json."""
    path = REPORT_OUTPUT_DIR / f"{resume_id}_report.json"
    path.write_text(report_json, encoding="utf-8")
    return path


def load_report(resume_id: str) -> Optional[dict]:
    """Load and parse a saved report. Returns None if not found."""
    path = REPORT_OUTPUT_DIR / f"{resume_id}_report.json"
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except json.JSONDecodeError:
        return None


def list_reports() -> list:
    """Return a list of all resume_ids that have saved reports."""
    return [
        p.stem.replace("_report", "")
        for p in REPORT_OUTPUT_DIR.glob("*_report.json")
    ]


def delete_report(resume_id: str) -> bool:
    """Delete a report file. Returns True if deleted."""
    path = REPORT_OUTPUT_DIR / f"{resume_id}_report.json"
    if path.exists():
        path.unlink()
        return True
    return False
