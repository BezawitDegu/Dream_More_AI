# backend/storage/resume_storage.py
# Saves and manages uploaded resume files on the local filesystem.

from typing import Optional
import shutil
from pathlib import Path

from fastapi import UploadFile

from backend.config.settings import RESUME_UPLOAD_DIR


async def save_resume_file(file: UploadFile, resume_id: str) -> Path:
    """
    Persist the uploaded resume file to /resumes/<resume_id>.<ext>.
    Resets the file cursor before reading so it works even if
    the file was partially read upstream.
    Returns the saved Path.
    """
    suffix = Path(file.filename or "resume.pdf").suffix.lower()
    dest   = RESUME_UPLOAD_DIR / f"{resume_id}{suffix}"

    await file.seek(0)
    with open(dest, "wb") as out_file:
        shutil.copyfileobj(file.file, out_file)

    return dest


def get_resume_path(resume_id: str) -> Optional[Path]:
    """Return the stored file path for a resume_id, or None if not found."""
    for ext in (".pdf", ".docx"):
        path = RESUME_UPLOAD_DIR / f"{resume_id}{ext}"
        if path.exists():
            return path
    return None


def delete_resume_file(resume_id: str) -> bool:
    """Delete a resume file from disk. Returns True if deleted."""
    path = get_resume_path(resume_id)
    if path and path.exists():
        path.unlink()
        return True
    return False
