# backend/ai/prompt_builder.py
# All prompts for Resume Analyzer, Chatbot, Learning Path.
# Grounded in Dream More Digitals company knowledge.


# ══════════════════════════════════════════════════════════════════════════
# MODULE 1 — RESUME ANALYZER
# ══════════════════════════════════════════════════════════════════════════

def build_resume_prompt(
    resume_chunks: list,
    job_chunks: list = None,
    analysis_type: str = "ATS",
    company_context: str = "",
) -> dict:
    system = (
        "You are an ATS resume expert. "
        "Analyse the resume text below. "
        "Base analysis ONLY on the resume. Do NOT invent anything."
    )

    resume_context = "\n\n".join(c["text"] for c in resume_chunks)[:800]
    context = f"RESUME:\n{resume_context}"

    if job_chunks:
        context += "\nJOB:\n" + "\n".join(c["text"] for c in job_chunks)[:300]

    if company_context:
        context += f"\nSTANDARDS:\n{company_context[:200]}"

    user = (
        "Return ONLY valid JSON with these keys: "
        "ats_score, skills_score, experience_score, education_score, "
        "formatting_score, grammar_score (all 0-100 integers), "
        "strengths (3 items), weaknesses (3 items), "
        "missing_keywords (3 items), suggestions (3 items)."
    )

    return {"system": system, "user": user, "context": context}


def build_job_match_prompt(resume_chunks: list, job_chunks: list) -> dict:
    system = (
        "You are a senior career coach and job-match specialist at Dream More Digitals. "
        "Compare the resume to the job description using ONLY the retrieved context. "
        "Do NOT invent information."
    )

    resume_context = "\n\n".join(c["text"] for c in resume_chunks)
    job_context    = "\n\n".join(c["text"] for c in job_chunks)
    context = (
        f"=== RESUME ===\n{resume_context}\n\n"
        f"=== JOB DESCRIPTION ===\n{job_context}"
    )

    user = (
        "Analyse how well this candidate matches the job description. "
        "Return ONLY valid JSON with these exact keys: "
        "match_score (0-100), skills_match (list), skills_gap (list), "
        "experience_match (0-100), strengths (list), weaknesses (list), suggestions (list)."
    )

    return {"system": system, "user": user, "context": context}


# ══════════════════════════════════════════════════════════════════════════
# MODULE 2 — STUDENT CHATBOT
# ══════════════════════════════════════════════════════════════════════════

CHATBOT_SYSTEM_PROMPT = (
    "You are DreamBot, the official AI assistant for Dream More Digitals. "
    "You help students with career advice, resume tips, interview preparation, "
    "skill development, and academic guidance. "
    "Be concise, friendly, and helpful. "
    "Always use the Dream More company knowledge provided to answer questions."
)


def build_chatbot_system_prompt(
    resume_chunks=None,
    *,
    resume_filename=None,
    indexing_missing=False,
) -> str:
    if not resume_chunks:
        return CHATBOT_SYSTEM_PROMPT

    resume_context = "\n\n".join(c["text"] for c in resume_chunks)
    name_hint = f" ({resume_filename})" if resume_filename else ""

    return (
        CHATBOT_SYSTEM_PROMPT
        + f"\n\nThe student has linked their resume{name_hint}. "
        "Use these excerpts for personalised advice. "
        "Do NOT claim skills not supported by this context.\n\n"
        f"=== STUDENT RESUME ===\n{resume_context}\n===================="
    )


# ══════════════════════════════════════════════════════════════════════════
# MODULE 3 — LEARNING PATH RECOMMENDER
# ══════════════════════════════════════════════════════════════════════════

def build_learning_path_prompt(
    goal: str,
    current_skills: list,
    education_level: str,
    duration_weeks: int = 12,
    company_context: str = "",
) -> str:
    skills_str = ", ".join(current_skills[:5]) if current_skills else "no prior skills"
    context_line = (
        f"\nDream More Academy context: {company_context[:200]}"
        if company_context else ""
    )

    return f"""You are an expert AI learning advisor at Dream More Digitals Academy in Bahir Dar, Ethiopia.

Student profile:
- Career Goal: {goal}
- Current Skills: {skills_str}
- Education Level: {education_level}
- Available Time: {duration_weeks} weeks
{context_line}

Analyse the skill gap and generate a smart personalised step-by-step learning roadmap.

Return ONLY valid JSON with these exact keys:
{{
  "title": "descriptive title",
  "total_weeks": {duration_weeks},
  "phases": [
    {{
      "phase": 1,
      "name": "phase name",
      "duration_weeks": 4,
      "topics": ["topic 1", "topic 2", "topic 3"],
      "resources": [{{"title": "name", "type": "course", "url": "https://..."}}],
      "milestone": "what student can build after this phase"
    }}
  ],
  "skills_gained": ["skill 1", "skill 2", "skill 3"],
  "career_outcomes": ["outcome 1", "outcome 2"],
  "tips": ["tip 1", "tip 2", "tip 3"]
}}

Generate exactly 3 phases progressing from beginner to advanced.
Each phase: 3 topics, 1-2 real resources with real URLs.
Return ONLY the JSON. No extra text."""
