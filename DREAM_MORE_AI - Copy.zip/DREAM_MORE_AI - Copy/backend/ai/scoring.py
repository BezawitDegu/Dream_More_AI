# backend/ai/scoring.py

def calculate_resume_score(
    ats: float,
    skills: float,
    experience: float,
    education: float,
    formatting: float,
    grammar: float,
) -> float:
    """
    Weighted composite ATS score (0-100):
      ATS          30%
      Skills       20%
      Experience   20%
      Education    10%
      Formatting   10%
      Grammar      10%

    Clamps each input to [0, 100] before weighting.
    """
    def clamp(v):
        return max(0.0, min(100.0, float(v)))

    return round(
        clamp(ats)        * 0.30
        + clamp(skills)   * 0.20
        + clamp(experience) * 0.20
        + clamp(education)  * 0.10
        + clamp(formatting) * 0.10
        + clamp(grammar)    * 0.10,
        2,
    )


def extract_scores_from_analysis(analysis: dict) -> float:
    """
    Pull individual dimension scores from the LLM analysis dict
    and compute the weighted composite score.
    Missing keys default to 0 (safe fallback).
    """
    return calculate_resume_score(
        ats=analysis.get("ats_score", 0),
        skills=analysis.get("skills_score", 0),
        experience=analysis.get("experience_score", 0),
        education=analysis.get("education_score", 0),
        formatting=analysis.get("formatting_score", 0),
        grammar=analysis.get("grammar_score", 0),
    )


def score_label(score: float) -> str:
    """Human-readable label for a composite score."""
    if score >= 85:
        return "Excellent"
    if score >= 70:
        return "Good"
    if score >= 50:
        return "Average"
    return "Needs Improvement"
