# backend/ai/report_generator.py

import json
from datetime import datetime
from backend.ai.scoring import score_label


def generate_report(resume_id: str, analysis: dict, score: float) -> str:
    """
    Build a complete structured JSON report from the LLM analysis.
    Saved to disk by report_storage.py.
    """
    report = {
        "resume_id":        resume_id,
        "generated_at":     datetime.utcnow().isoformat() + "Z",
        "composite_score":  score,
        "label":            score_label(score),
        "dimension_scores": {
            "ats":         analysis.get("ats_score",        0),
            "skills":      analysis.get("skills_score",     0),
            "experience":  analysis.get("experience_score", 0),
            "education":   analysis.get("education_score",  0),
            "formatting":  analysis.get("formatting_score", 0),
            "grammar":     analysis.get("grammar_score",    0),
        },
        "strengths":        _ensure_list(analysis.get("strengths",        [])),
        "weaknesses":       _ensure_list(analysis.get("weaknesses",       [])),
        "missing_keywords": _ensure_list(analysis.get("missing_keywords", [])),
        "suggestions":      _ensure_list(analysis.get("suggestions",      [])),
        "summary":          analysis.get("summary", ""),
    }
    return json.dumps(report, indent=4, ensure_ascii=False)


def _ensure_list(value) -> list:
    """Make sure a value is always a list."""
    if isinstance(value, list):
        return value
    if isinstance(value, str) and value:
        return [value]
    return []
