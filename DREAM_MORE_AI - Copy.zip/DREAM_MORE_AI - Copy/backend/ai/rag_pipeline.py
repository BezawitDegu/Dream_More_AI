# backend/ai/rag_pipeline.py
# RAG pipeline: chunk → embed (nomic-embed-text) → upsert ChromaDB → retrieve
# Fully local, no external APIs.

from langchain_text_splitters import RecursiveCharacterTextSplitter

from backend.database.chroma_db import get_resume_collection, get_jobs_collection
from backend.ai.ollama_client import generate_embedding


# ── Chunking ───────────────────────────────────────────────────────────────

def chunk_text(text: str, doc_id: str, doc_type: str = "resume") -> list:
    """
    Split a document into overlapping text chunks with metadata.

    Returns list of dicts: {id, text, metadata}
    chunk_size=300 chars keeps each chunk under nomic-embed-text's sweet spot.
    """
    splitter = RecursiveCharacterTextSplitter(
        chunk_size=200,      # reduced from 300 — smaller chunks = faster embedding
        chunk_overlap=30,    # reduced from 50
        length_function=len,
    )
    raw_chunks = splitter.split_text(text)
    return [
        {
            "id":       f"{doc_id}_{doc_type}_chunk_{i}",
            "text":     chunk,
            "metadata": {
                "doc_id":      doc_id,
                "doc_type":    doc_type,
                "chunk_index": i,
            },
        }
        for i, chunk in enumerate(raw_chunks)
    ]


def chunk_resume_text(resume_text: str, resume_id: str) -> list:
    return chunk_text(resume_text, resume_id, doc_type="resume")


def chunk_job_text(job_text: str, job_id: str) -> list:
    return chunk_text(job_text, job_id, doc_type="job")


# ── Storage ────────────────────────────────────────────────────────────────

def _store(chunks: list, collection) -> bool:
    """
    Embed each chunk with nomic-embed-text and upsert into ChromaDB.
    Uses upsert so re-processing the same document never creates duplicates.
    """
    if not chunks:
        return False
    for chunk in chunks:
        embedding = generate_embedding(chunk["text"])
        collection.upsert(
            ids=[chunk["id"]],
            documents=[chunk["text"]],
            embeddings=[embedding],
            metadatas=[chunk["metadata"]],
        )
    return True


def store_resume_chunks(chunks: list) -> bool:
    return _store(chunks, get_resume_collection())


def store_job_chunks(chunks: list) -> bool:
    return _store(chunks, get_jobs_collection())


# ── Retrieval ──────────────────────────────────────────────────────────────

def _retrieve(
    query: str,
    collection,
    top_k: int = 6,
    *,
    doc_id: str | None = None,
) -> list:
    """
    Embed the query, then return the top-k most similar chunks.

    Safely caps n_results to the actual number of stored documents
    so ChromaDB never raises a 'n_results > count' error.

    When doc_id is set, only chunks belonging to that document are considered.

    Returns list of dicts: {text, metadata}
    """
    where = {"doc_id": doc_id} if doc_id else None

    if doc_id:
        stored = collection.get(where=where)
        count = len(stored.get("ids") or [])
    else:
        count = collection.count()

    if count == 0:
        return []

    n = min(top_k, count)
    query_embedding = generate_embedding(query)

    query_kwargs = {
        "query_embeddings": [query_embedding],
        "n_results": n,
        "include": ["documents", "metadatas"],
    }
    if where:
        query_kwargs["where"] = where

    results = collection.query(**query_kwargs)

    docs  = results.get("documents", [[]])[0]
    metas = results.get("metadatas",  [[]])[0]
    return [{"text": d, "metadata": m} for d, m in zip(docs, metas)]


def retrieve_resume_chunks(
    query: str,
    top_k: int = 3,          # reduced from 6 — less context = faster LLM
    resume_id: str = None,
) -> list:
    return _retrieve(
        query,
        get_resume_collection(),
        top_k,
        doc_id=resume_id,
    )


def retrieve_job_chunks(query: str, top_k: int = 2) -> list:  # reduced from 6
    return _retrieve(query, get_jobs_collection(), top_k)


# ── Deletion ───────────────────────────────────────────────────────────────

def delete_resume_chunks(resume_id: str) -> bool:
    """Remove all ChromaDB entries that belong to a specific resume."""
    collection = get_resume_collection()
    try:
        results = collection.get(where={"doc_id": resume_id})
        ids = results.get("ids", [])
        if ids:
            collection.delete(ids=ids)
        return True
    except Exception as e:
        print(f"⚠️  Could not delete chunks for {resume_id}: {e}")
        return False


def delete_job_chunks(job_id: str) -> bool:
    """Remove all ChromaDB entries that belong to a specific job."""
    collection = get_jobs_collection()
    try:
        results = collection.get(where={"doc_id": job_id})
        ids = results.get("ids", [])
        if ids:
            collection.delete(ids=ids)
        return True
    except Exception as e:
        print(f"⚠️  Could not delete job chunks for {job_id}: {e}")
        return False
