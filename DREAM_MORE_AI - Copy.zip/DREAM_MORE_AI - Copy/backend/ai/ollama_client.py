# backend/ai/ollama_client.py
# AI client — auto-selects Groq (fast, free) or Ollama (local fallback).
# Groq: under 3 seconds. Ollama: 30-90 seconds on CPU.

import json
import os
import re
import traceback
from urllib import error, request

from backend.config.settings import (
    OLLAMA_BASE_URL,
    OLLAMA_LLM_MODEL,
    OLLAMA_EMB_MODEL,
    OLLAMA_TIMEOUT,
)

_ANSI_RE  = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")
# Read AFTER settings loads dotenv — so config.env values are available
_AI_MODE  = os.getenv("AI_MODE", "ollama").lower()

# ── Speed profiles ─────────────────────────────────────────────────────────
# MAXIMUM SPEED — phi3 on CPU, greedy decoding, all 4 cores

# Resume analysis — minimum tokens, greedy decoding
_FAST_OPTIONS = {
    "num_ctx":        1024,
    "num_predict":    250,
    "temperature":    0.0,
    "top_k":          1,
    "top_p":          1.0,
    "repeat_penalty": 1.0,
    "num_thread":     4,
}

# Chatbot — fast but with enough context for company KB
_CHAT_OPTIONS = {
    "num_ctx":        2048,
    "num_predict":    150,
    "temperature":    0.0,
    "top_k":          1,
    "top_p":          1.0,
    "repeat_penalty": 1.0,
    "num_thread":     4,
}

# Learning path
_LP_OPTIONS = {
    "num_ctx":        1024,
    "num_predict":    600,
    "temperature":    0.0,
    "top_k":          1,
    "top_p":          1.0,
    "repeat_penalty": 1.0,
    "num_thread":     4,
}


# ── Internal helpers ───────────────────────────────────────────────────────

def _post(endpoint: str, payload: dict, timeout: int = None) -> dict:
    timeout = timeout or OLLAMA_TIMEOUT
    data = json.dumps(payload).encode("utf-8")
    req  = request.Request(
        f"{OLLAMA_BASE_URL}{endpoint}",
        data=data,
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def _clean_json(raw: str) -> str:
    s = _ANSI_RE.sub("", raw.strip())
    s = s.replace("```json", "").replace("```", "").strip()
    start, end = s.find("{"), s.rfind("}")
    if start != -1 and end > start:
        return s[start:end + 1]
    return s


def _parse_json(raw: str) -> dict:
    cleaned = _clean_json(raw)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            return json.loads(match.group(0))
        raise ValueError(f"Could not parse JSON:\n{raw[:300]}")


# ── Embeddings ─────────────────────────────────────────────────────────────

def generate_embedding(text: str) -> list:
    """Fast local embedding via nomic-embed-text. Max 400 chars."""
    try:
        clean = " ".join(text.split())[:400]
        out   = _post(
            "/api/embeddings",
            {"model": OLLAMA_EMB_MODEL, "prompt": clean},
            timeout=20,
        )
        emb = out.get("embedding", [])
        return emb if emb else [0.0] * 768
    except Exception as e:
        print(f"⚠️  Embedding error: {e}")
        return [0.0] * 768


# ── Resume / Job Analysis ──────────────────────────────────────────────────

def run_analysis(prompt: dict) -> dict:
    """Resume analysis — uses Groq if configured, else Ollama."""
    if _AI_MODE == "groq":
        from backend.ai.groq_client import groq_run_analysis, groq_available
        if groq_available():
            return groq_run_analysis(prompt)
    # Ollama fallback
    try:
        context = prompt['context'][:400]
        full_prompt = (
            f"{prompt['system']}\n\n"
            f"CONTEXT:\n{context}\n\n"
            f"{prompt['user']}\n"
            "Return ONLY valid JSON. No extra text."
        )
        out = _post("/api/generate", {
            "model":   OLLAMA_LLM_MODEL,
            "prompt":  full_prompt,
            "stream":  False,
            "format":  "json",
            "options": _FAST_OPTIONS,
        })
        raw = out.get("response", "")
        return raw if isinstance(raw, dict) else _parse_json(raw)
    except KeyError as e:
        return {"error": f"Missing prompt key: {e}"}
    except error.HTTPError as e:
        return {"error": f"Ollama HTTP {e.code}"}
    except error.URLError as e:
        return {"error": "Ollama not reachable — run `ollama serve`."}
    except ValueError as e:
        return {"error": str(e)}
    except Exception as e:
        traceback.print_exc()
        return {"error": f"Analysis failed: {e}"}


# ── Student Chatbot ────────────────────────────────────────────────────────

def run_chat(system_prompt: str, messages: list) -> str:
    """Chat — uses Groq if configured, else Ollama."""
    if _AI_MODE == "groq":
        from backend.ai.groq_client import groq_run_chat, groq_available
        if groq_available():
            return groq_run_chat(system_prompt, messages)
    # Ollama fallback
    try:
        recent = messages[-2:] if len(messages) > 2 else messages
        # Increased from 400 to 1200 so company address always reaches the model
        all_messages = [{"role": "system", "content": system_prompt[:1200]}] + recent
        out = _post("/api/chat", {
            "model":    OLLAMA_LLM_MODEL,
            "messages": all_messages,
            "stream":   False,
            "options":  _CHAT_OPTIONS,
        })
        return out.get("message", {}).get("content", "").strip()
    except error.URLError:
        return "Sorry, AI service is unavailable. Run `ollama serve`."
    except Exception as e:
        traceback.print_exc()
        return f"Error: {e}"


# ── Learning Path Recommender ──────────────────────────────────────────────

def run_learning_path(prompt: str) -> dict:
    """Learning path — uses Groq if configured, else Ollama."""
    if _AI_MODE == "groq":
        from backend.ai.groq_client import groq_run_learning_path, groq_available
        if groq_available():
            return groq_run_learning_path(prompt)
    # Ollama fallback
    raw = ""
    try:
        out = _post("/api/generate", {
            "model":   OLLAMA_LLM_MODEL,
            "prompt":  prompt[:1500],
            "stream":  False,
            "format":  "json",
            "options": _LP_OPTIONS,
        })
        raw = out.get("response", "")
        if isinstance(raw, dict):
            return raw
        parsed = _parse_json(raw)
        parsed.setdefault("phases", [])
        parsed.setdefault("title", "Your Learning Path")
        parsed.setdefault("total_weeks", 12)
        parsed.setdefault("skills_gained", [])
        parsed.setdefault("career_outcomes", [])
        parsed.setdefault("tips", [])
        return parsed
    except Exception as e:
        print(f"⚠️  Learning path error: {e}")
        return {
            "title": "Your Learning Path",
            "total_weeks": 12,
            "phases": [{
                "phase": 1,
                "name": "Foundation",
                "duration_weeks": 4,
                "topics": ["Core concepts", "Fundamentals", "Basics"],
                "resources": [{"title": "Dream More Academy", "type": "course",
                               "url": "https://www.dreammoredigitals.com/academy"}],
                "milestone": "Understand the core fundamentals"
            }],
            "skills_gained": ["Core skills for your goal"],
            "career_outcomes": ["Entry-level role in your target field"],
            "tips": ["Practice daily", "Contact Dream More Academy: +251 993 132 122"],
        }
