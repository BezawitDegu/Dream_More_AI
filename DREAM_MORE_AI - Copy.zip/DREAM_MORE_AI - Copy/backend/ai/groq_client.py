# backend/ai/groq_client.py
# Groq API — free, ultra-fast LLaMA3 inference.
# Resume: ~2 sec | Chatbot: ~1 sec | Learning Path: ~3 sec
# Get free API key at: https://console.groq.com

import json
import os
import re
import traceback

GROQ_MODEL  = os.getenv("GROQ_MODEL", "llama3-8b-8192")
_ANSI_RE    = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]")


def _get_client():
    """Create Groq client. Returns None if not configured."""
    try:
        from groq import Groq
        key = os.getenv("GROQ_API_KEY", "")
        if not key or key == "your_groq_api_key_here":
            return None
        return Groq(api_key=key)
    except ImportError:
        print("⚠️  groq package not installed. Run: py -m pip install groq")
        return None


def groq_available() -> bool:
    return _get_client() is not None


def _clean_json(raw: str) -> str:
    s = _ANSI_RE.sub("", raw.strip())
    s = s.replace("```json", "").replace("```", "").strip()
    start, end = s.find("{"), s.rfind("}")
    if start != -1 and end > start:
        return s[start:end + 1]
    return s


def _parse_json(raw: str) -> dict:
    cleaned = _clean_json(raw)
    try:
        return json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if match:
            return json.loads(match.group(0))
        raise ValueError(f"Cannot parse JSON: {raw[:200]}")


# ── Resume Analysis ────────────────────────────────────────────────────────

def groq_run_analysis(prompt: dict) -> dict:
    """Resume ATS analysis via Groq — ~2 seconds."""
    try:
        client = _get_client()
        if not client:
            return {"error": "Groq not configured. Add GROQ_API_KEY to config.env"}

        context  = prompt['context'][:2000]
        user_msg = f"CONTEXT:\n{context}\n\n{prompt['user']}\nReturn ONLY valid JSON."

        resp = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": prompt['system']},
                {"role": "user",   "content": user_msg},
            ],
            temperature=0.1,
            max_tokens=800,
            response_format={"type": "json_object"},
        )
        return _parse_json(resp.choices[0].message.content)

    except Exception as e:
        traceback.print_exc()
        return {"error": f"Groq analysis failed: {e}"}


# ── Chatbot ────────────────────────────────────────────────────────────────

def groq_run_chat(system_prompt: str, messages: list) -> str:
    """Chatbot reply via Groq — ~1 second."""
    try:
        client = _get_client()
        if not client:
            return "Groq not configured. Add GROQ_API_KEY to config.env"

        resp = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": system_prompt[:2000]},
                *messages[-4:],
            ],
            temperature=0.3,
            max_tokens=300,
        )
        return resp.choices[0].message.content.strip()

    except Exception as e:
        traceback.print_exc()
        return f"Error: {e}"


# ── Learning Path ──────────────────────────────────────────────────────────

def groq_run_learning_path(prompt: str) -> dict:
    """Learning path generation via Groq — ~3 seconds."""
    try:
        client = _get_client()
        if not client:
            return {"error": "Groq not configured. Add GROQ_API_KEY to config.env"}

        resp = client.chat.completions.create(
            model=GROQ_MODEL,
            messages=[
                {"role": "system", "content": "You are an expert learning advisor. Return only valid JSON."},
                {"role": "user",   "content": prompt[:2500]},
            ],
            temperature=0.3,
            max_tokens=1500,
            response_format={"type": "json_object"},
        )
        raw    = resp.choices[0].message.content
        parsed = _parse_json(raw)
        parsed.setdefault("phases",          [])
        parsed.setdefault("title",           "Your Learning Path")
        parsed.setdefault("total_weeks",     12)
        parsed.setdefault("skills_gained",   [])
        parsed.setdefault("career_outcomes", [])
        parsed.setdefault("tips",            [])
        return parsed

    except Exception as e:
        traceback.print_exc()
        return {"error": f"Groq learning path failed: {e}"}
