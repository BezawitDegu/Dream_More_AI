import json
import unittest

from backend.ai import ollama_client


class OllamaClientTests(unittest.TestCase):
    def test_run_analysis_parses_json_when_output_has_ansi_escape_sequences(self):
        response_payload = {
            "response": '\x1b[32m{\n  "ats_score": 85,\n  "skills_score": 75,\n  "education_score": 95,\n  "formatting_score": 80,\n  "grammar_score": 90,\n  "strengths": ["Clear summary"],\n  "weaknesses": ["Needs more experience"],\n  "suggestions": ["Add projects"]\n}\x1b[0m'
        }

        class FakeResponse:
            def __enter__(self):
                return self

            def __exit__(self, exc_type, exc, tb):
                return False

            def read(self):
                return json.dumps(response_payload).encode("utf-8")

        def fake_urlopen(*args, **kwargs):
            return FakeResponse()

        original_urlopen = ollama_client.request.urlopen
        ollama_client.request.urlopen = fake_urlopen
        try:
            result = ollama_client.run_analysis({
                "system": "system prompt",
                "user": "user prompt",
                "context": "context text",
            })
        finally:
            ollama_client.request.urlopen = original_urlopen

        self.assertEqual(result["ats_score"], 85)
        self.assertEqual(result["skills_score"], 75)
        self.assertEqual(result["strengths"], ["Clear summary"])


if __name__ == "__main__":
    unittest.main()
