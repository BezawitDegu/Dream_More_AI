# backend/tests/test_resume.py

import asyncio
from backend.ai.rag_pipeline import chunk_resume_text, store_resume_chunks
from backend.ai.prompt_builder import build_resume_prompt
from backend.ai.ollama_client import run_analysis
from backend.ai.scoring import calculate_resume_score
from backend.ai.report_generator import generate_report

async def main():
    # Use raw resume text instead of PDF parsing
    resume_text = """
    Bezawit Degu Kasegn
    Bahir Dar, Ethiopia | +251 942 376 001 | bezawit0@gmail.com
    LinkedIn: [Link] | GitHub: [Link] | Portfolio: [Link]
    Professional Summary
    Dedicated 4th-year Computer Science student...
    (paste the full resume text here)
    """

    # Step 1: Chunk + embed
    chunks = chunk_resume_text(resume_text, "resume_001")
    store_resume_chunks(chunks)

    # Step 2: Build prompt
    prompt = build_resume_prompt(chunks, analysis_type="ATS")

    # Step 3: Run analysis with Ollama
    analysis = run_analysis(prompt)

    # Step 4: Score resume (dummy values for now)
    score = calculate_resume_score(
        ats=80, skills=70, experience=75, education=60, formatting=85, grammar=90
    )

    # Step 5: Generate report
    report = generate_report("resume_001", analysis, score)
    print(report)

if __name__ == "__main__":
    asyncio.run(main())
