# backend/main.py
# DREAM MORE AI — FastAPI entry point.
# Serves the frontend UI + all backend API routes.
# 100% local: Ollama (LLaMA3 + nomic-embed-text) + ChromaDB RAG. Zero cost.

from pathlib import Path

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from backend.config.settings import API_HOST, API_PORT, API_RELOAD
from backend.controllers.resume_controller import router as resume_router
from backend.controllers.chatbot_controller import router as chatbot_router
from backend.controllers.learning_path_controller import router as learning_path_router

# ── Paths ──────────────────────────────────────────────────────────────────
BASE_DIR     = Path(__file__).resolve().parent.parent   # project root
FRONTEND_DIR = BASE_DIR / "frontend"
STATIC_DIR   = FRONTEND_DIR / "static"

# ── App ────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="DREAM MORE AI",
    description=(
        "AI-powered student platform — fully local, zero cost.\n\n"
        "**Three modules:**\n"
        "1. **Resume Analyzer** — ATS scoring + job matching via RAG\n"
        "2. **Student Chatbot** — multi-turn AI conversation\n"
        "3. **Learning Path Recommender** — personalised career roadmaps\n\n"
        "**Stack:** Ollama (LLaMA3) · nomic-embed-text · ChromaDB · FastAPI"
    ),
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# ── CORS ───────────────────────────────────────────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Static files (CSS, JS, assets) ────────────────────────────────────────
app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

# ── API routers ────────────────────────────────────────────────────────────
app.include_router(resume_router)
app.include_router(chatbot_router)
app.include_router(learning_path_router)

# ── Frontend — serve index.html on root ───────────────────────────────────
@app.get("/", include_in_schema=False)
async def serve_frontend():
    """Serve the Resume Analyzer web UI."""
    return FileResponse(str(FRONTEND_DIR / "index.html"))

# ── Health check ───────────────────────────────────────────────────────────
@app.get("/health", tags=["Health"], summary="Health check")
async def health():
    """Check API, Ollama, and Groq status."""
    from urllib import request as url_request, error as url_error
    import os

    # Check Ollama
    ollama_status = "unreachable — run `ollama serve`"
    try:
        with url_request.urlopen("http://localhost:11434/api/tags", timeout=3) as r:
            if r.status == 200:
                ollama_status = "ok"
    except Exception:
        pass

    # Check Groq
    ai_mode = os.getenv("AI_MODE", "ollama").lower()
    groq_status = "not configured"
    if ai_mode == "groq":
        try:
            from backend.ai.groq_client import groq_available
            groq_status = "ok" if groq_available() else "API key missing — add to config.env"
        except Exception:
            groq_status = "error"

    return {
        "api":      "ok",
        "ai_mode":  ai_mode,
        "ollama":   ollama_status,
        "groq":     groq_status,
    }

# ── Entry point ────────────────────────────────────────────────────────────
if __name__ == "__main__":
    uvicorn.run(
        "backend.main:app",
        host=API_HOST,
        port=API_PORT,
        reload=API_RELOAD,
    )
