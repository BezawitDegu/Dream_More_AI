# backend/repositories/resume_repository.py
# In-memory resume registry with JSON file persistence.
# Tracks every uploaded resume's metadata across server restarts.

from typing import Optional
import json
from datetime import datetime
from pathlib import Path

from backend.config.settings import REPORT_OUTPUT_DIR

_REGISTRY_FILE = REPORT_OUTPUT_DIR / "resume_registry.json"

# { resume_id: {id, filename, uploaded_at, status, score} }
_registry: dict = {}


# ── Persistence helpers ────────────────────────────────────────────────────

def _load() -> None:
    """Load registry from disk on startup."""
    global _registry
    if _REGISTRY_FILE.exists():
        try:
            _registry = json.loads(_REGISTRY_FILE.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            _registry = {}


def _save() -> None:
    """Persist current registry to disk."""
    try:
        _REGISTRY_FILE.write_text(
            json.dumps(_registry, indent=2, ensure_ascii=False),
            encoding="utf-8",
        )
    except OSError as e:
        print(f"⚠️  Could not save registry: {e}")


# Load on module import
_load()


# ── Public API ─────────────────────────────────────────────────────────────

def register_resume(resume_id: str, filename: str) -> dict:
    """Add a new resume entry. Initial status: 'uploaded'."""
    entry = {
        "id":          resume_id,
        "filename":    filename,
        "uploaded_at": datetime.utcnow().isoformat() + "Z",
        "status":      "uploaded",
        "score":       None,
    }
    _registry[resume_id] = entry
    _save()
    return entry


def update_resume_status(resume_id: str, status: str, score: float = None) -> None:
    """Update status and optionally the composite score."""
    if resume_id not in _registry:
        return
    _registry[resume_id]["status"] = status
    if score is not None:
        _registry[resume_id]["score"] = score
    _save()


def get_resume(resume_id: str) -> Optional[dict]:
    """Return the registry entry for a resume_id, or None."""
    return _registry.get(resume_id)


def list_resumes() -> list:
    """Return all registry entries, newest first."""
    entries = list(_registry.values())
    entries.sort(key=lambda e: e.get("uploaded_at", ""), reverse=True)
    return entries


def delete_resume(resume_id: str) -> bool:
    """Remove a resume from the registry. Returns True if it existed."""
    if resume_id in _registry:
        del _registry[resume_id]
        _save()
        return True
    return False
