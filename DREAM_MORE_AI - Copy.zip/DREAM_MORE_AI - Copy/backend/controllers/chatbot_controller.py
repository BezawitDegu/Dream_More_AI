# backend/controllers/chatbot_controller.py
# FastAPI router — Student Chatbot module.
# 100% local: LLaMA3 via Ollama. Zero cost.

import uuid
from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from backend.services.chatbot_service import (
    chat,
    clear_session,
    get_history,
    list_sessions,
)

router = APIRouter(prefix="/chatbot", tags=["Student Chatbot"])


# ── Request models ─────────────────────────────────────────────────────────

class ChatRequest(BaseModel):
    session_id: str = ""        # empty = auto-create new session
    message:    str
    resume_id:  str = ""        # optional — active resume from Resume Analyzer


class ClearRequest(BaseModel):
    session_id: str


# ── Routes ─────────────────────────────────────────────────────────────────

@router.post("/chat", summary="Send a message to DreamBot")
async def chatbot_chat(body: ChatRequest):
    """
    Send a message and get a reply from DreamBot (LLaMA3 local).

    - If session_id is empty a new session is created automatically.
    - Each session keeps the last 20 messages in memory so DreamBot
      remembers the conversation context.
    - If resume_id is provided, relevant resume excerpts are retrieved
      via ChromaDB RAG and injected into the system prompt for this turn.

    Returns: session_id, reply, turn, history length, resume RAG metadata.
    """
    if not body.message.strip():
        raise HTTPException(status_code=422, detail="Message cannot be empty.")

    session_id = body.session_id.strip() or str(uuid.uuid4())
    resume_id  = body.resume_id.strip() or None

    result = chat(session_id, body.message, resume_id=resume_id)

    if "error" in result:
        raise HTTPException(status_code=404, detail=result["error"])

    return JSONResponse(result)


@router.post("/clear", summary="Clear conversation history for a session")
async def chatbot_clear(body: ClearRequest):
    """Wipe the conversation history so DreamBot starts fresh."""
    if not body.session_id.strip():
        raise HTTPException(status_code=422, detail="session_id cannot be empty.")
    return JSONResponse(clear_session(body.session_id))


@router.get("/history/{session_id}", summary="Get conversation history")
async def chatbot_history(session_id: str):
    """Return the full message history for a session."""
    history = get_history(session_id)
    return JSONResponse({
        "session_id":     session_id,
        "turns":          len(history) // 2,
        "history":        history,
    })


@router.get("/sessions", summary="List all active chat sessions")
async def chatbot_sessions():
    """Return all active session IDs and their turn counts."""
    return JSONResponse({"sessions": list_sessions()})
