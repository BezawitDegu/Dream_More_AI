# backend/controllers/resume_controller.py
# FastAPI router — Resume Analyzer module.
# All AI is done locally via RAG + ChromaDB + Ollama/LLaMA3. Zero cost.

import os
import uuid

from fastapi import APIRouter, File, Form, HTTPException, UploadFile
from fastapi.responses import JSONResponse

from backend.config.settings import ALLOWED_EXTENSIONS, MAX_UPLOAD_SIZE_MB
from backend.services.resume_service import extract_text_from_resume
from backend.services.jobmatch_service import match_resume_to_job
from backend.ai.rag_pipeline import (
    chunk_resume_text,
    store_resume_chunks,
    retrieve_resume_chunks,
    delete_resume_chunks,
)
from backend.ai.prompt_builder import build_resume_prompt
from backend.ai.ollama_client import run_analysis
from backend.ai.scoring import extract_scores_from_analysis, score_label
from backend.ai.report_generator import generate_report
from backend.storage.resume_storage import save_resume_file, delete_resume_file
from backend.storage.report_storage import (
    save_report, load_report, list_reports, delete_report,
)
from backend.repositories.resume_repository import (
    register_resume,
    update_resume_status,
    get_resume,
    list_resumes,
    delete_resume,
)
from backend.database.seed_kb import retrieve_resume_context

router = APIRouter(prefix="/resume", tags=["Resume Analyzer"])


# ══════════════════════════════════════════════════════════════════════════
# STEP 1 — Upload
# ══════════════════════════════════════════════════════════════════════════

@router.post("/upload", summary="Upload a resume (PDF or DOCX)")
async def upload_resume(file: UploadFile = File(...)):
    """
    Upload a resume and index it into ChromaDB.

    Pipeline:
      validate file → save to disk → extract text → chunk → embed → upsert ChromaDB

    Returns a resume_id that is used in all subsequent calls.
    """
    _validate_file(file)

    resume_id = str(uuid.uuid4())
    filename  = file.filename or f"{resume_id}.pdf"

    # 1. Save raw file to disk
    await save_resume_file(file, resume_id)

    # 2. Extract text (seek back to 0 after save)
    await file.seek(0)
    try:
        text = await extract_text_from_resume(file)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    # 3. Register + chunk + embed + store
    register_resume(resume_id, filename)
    update_resume_status(resume_id, "indexing")

    chunks = chunk_resume_text(text, resume_id)
    store_resume_chunks(chunks)

    update_resume_status(resume_id, "ready")

    return JSONResponse({
        "resume_id": resume_id,
        "filename":  filename,
        "chunks":    len(chunks),
        "status":    "ready",
        "message":   "Resume uploaded and indexed. You can now call /analyze or /match.",
    })


# ══════════════════════════════════════════════════════════════════════════
# STEP 2 — Analyse
# ══════════════════════════════════════════════════════════════════════════

@router.post("/analyze/{resume_id}", summary="Run ATS analysis on an uploaded resume")
async def analyze_resume(resume_id: str):
    """
    Run a full ATS analysis on an already-uploaded resume.

    Pipeline:
      retrieve chunks (ChromaDB RAG) → build prompt → LLaMA3 (local) →
      compute weighted score → save report → return result
    """
    _check_exists(resume_id)
    update_resume_status(resume_id, "analysing")

    # RAG: retrieve most relevant resume chunks
    chunks = retrieve_resume_chunks(
        query="skills experience education projects summary achievements",
        top_k=2,
        resume_id=resume_id,
    )
    if not chunks:
        update_resume_status(resume_id, "error")
        raise HTTPException(
            status_code=404,
            detail="No indexed data found for this resume. Please re-upload.",
        )

    # Retrieve Dream More hiring standards from resume KB
    company_context = retrieve_resume_context(
        "skills experience education hiring standards keywords", top_k=2
    )

    # Build RAG prompt + run local LLM
    prompt   = build_resume_prompt(chunks, analysis_type="ATS", company_context=company_context)
    analysis = run_analysis(prompt)

    if "error" in analysis:
        update_resume_status(resume_id, "error")
        raise HTTPException(status_code=503, detail=analysis["error"])

    # Score + persist report
    score       = extract_scores_from_analysis(analysis)
    label       = score_label(score)
    report_json = generate_report(resume_id, analysis, score)
    save_report(resume_id, report_json)
    update_resume_status(resume_id, "done", score=score)

    return JSONResponse({
        "resume_id": resume_id,
        "score":     score,
        "label":     label,
        "analysis":  analysis,
    })


# ══════════════════════════════════════════════════════════════════════════
# STEP 3 — Job Match
# ══════════════════════════════════════════════════════════════════════════

@router.post("/match/{resume_id}", summary="Match resume against a job description")
async def match_job(
    resume_id: str,
    job_description: str = Form(..., description="Paste the full job description"),
):
    """
    Match an uploaded resume against a job description using RAG + LLaMA3.

    Pipeline:
      chunk job desc → embed → store in ChromaDB →
      retrieve resume chunks + job chunks → build prompt → LLaMA3 → return result
    """
    _check_exists(resume_id)

    if not job_description.strip():
        raise HTTPException(status_code=422, detail="Job description cannot be empty.")

    result = match_resume_to_job(resume_id, job_description)

    if "error" in result:
        raise HTTPException(status_code=503, detail=result["error"])

    return JSONResponse(result)


# ══════════════════════════════════════════════════════════════════════════
# Reports & Listing
# ══════════════════════════════════════════════════════════════════════════

@router.get("/report/{resume_id}", summary="Get the saved analysis report")
async def get_report(resume_id: str):
    """Retrieve a previously generated analysis report from disk."""
    report = load_report(resume_id)
    if not report:
        raise HTTPException(
            status_code=404,
            detail="Report not found. Run /analyze/{resume_id} first.",
        )
    return JSONResponse(report)


@router.get("/list", summary="List all uploaded resumes")
async def list_all_resumes():
    return JSONResponse({"resumes": list_resumes()})


@router.get("/reports", summary="List all saved reports")
async def list_all_reports():
    return JSONResponse({"reports": list_reports()})


# ══════════════════════════════════════════════════════════════════════════
# Delete
# ══════════════════════════════════════════════════════════════════════════

@router.delete("/{resume_id}", summary="Delete a resume and all its data")
async def delete_resume_endpoint(resume_id: str):
    """
    Remove: raw file from disk + ChromaDB vectors + report + registry entry.
    """
    delete_resume_file(resume_id)
    delete_resume_chunks(resume_id)
    delete_report(resume_id)
    delete_resume(resume_id)
    return JSONResponse({"message": f"Resume {resume_id} and all related data deleted."})


# ══════════════════════════════════════════════════════════════════════════
# Internal helpers
# ══════════════════════════════════════════════════════════════════════════

def _validate_file(file: UploadFile) -> None:
    ext = os.path.splitext(file.filename or "")[1].lower()
    if ext not in ALLOWED_EXTENSIONS:
        raise HTTPException(
            status_code=415,
            detail=f"File type '{ext}' is not supported. Allowed: {sorted(ALLOWED_EXTENSIONS)}",
        )


def _check_exists(resume_id: str) -> None:
    if not get_resume(resume_id):
        raise HTTPException(
            status_code=404,
            detail=f"Resume '{resume_id}' not found. Please upload it first.",
        )
