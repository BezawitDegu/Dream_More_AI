# backend/controllers/learning_path_controller.py
# FastAPI router — Learning Path Recommender module.
# 100% local: LLaMA3 via Ollama. Zero cost.

from fastapi import APIRouter, HTTPException
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from typing import List

from backend.services.learning_path_service import generate_learning_path

router = APIRouter(prefix="/learning-path", tags=["Learning Path Recommender"])


# ── Request model ──────────────────────────────────────────────────────────

class LearningPathRequest(BaseModel):
    goal: str = Field(
        ...,
        description="Career goal, e.g. 'Become a full-stack web developer'",
        min_length=3,
    )
    current_skills: List[str] = Field(
        default=[],
        description="List of skills the student already has",
    )
    education_level: str = Field(
        default="Bachelor's student",
        description="e.g. 'High school', 'Bachelor student', 'Self-taught'",
    )
    duration_weeks: int = Field(
        default=12,
        ge=1,
        le=104,
        description="Target duration in weeks (1–104)",
    )


# ── Routes ─────────────────────────────────────────────────────────────────

@router.post("/generate", summary="Generate a personalised learning path")
async def generate(body: LearningPathRequest):
    """
    Generate a step-by-step personalised learning path using LLaMA3 (local).

    Input: career goal, current skills, education level, target duration.

    Returns a structured roadmap with:
    - Phases (each with topics, resources, milestone)
    - Skills gained
    - Career outcomes
    - Practical tips
    """
    result = generate_learning_path(
        goal=body.goal,
        current_skills=body.current_skills,
        education_level=body.education_level,
        duration_weeks=body.duration_weeks,
    )

    if "error" in result:
        raise HTTPException(status_code=503, detail=result["error"])

    return JSONResponse(result)
