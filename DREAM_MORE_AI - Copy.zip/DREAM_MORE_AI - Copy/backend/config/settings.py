# backend/config/settings.py
# Central configuration — all values are local, no cloud keys required.

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env or config.env from project root
_base = Path(__file__).resolve().parent.parent.parent
load_dotenv(_base / "config.env")
load_dotenv(_base / ".env")

# ── Paths ──────────────────────────────────────────────────────────────────
BASE_DIR          = Path(__file__).resolve().parent.parent.parent  # project root
RESUME_UPLOAD_DIR = BASE_DIR / "resumes"
REPORT_OUTPUT_DIR = BASE_DIR / "reports"
VECTOR_STORE_DIR  = BASE_DIR / "vector_store"

# Ensure all directories exist on startup
for _d in (RESUME_UPLOAD_DIR, REPORT_OUTPUT_DIR, VECTOR_STORE_DIR):
    _d.mkdir(parents=True, exist_ok=True)

# ── Ollama (fully local) ───────────────────────────────────────────────────
OLLAMA_BASE_URL  = os.getenv("OLLAMA_BASE_URL",  "http://localhost:11434")
OLLAMA_LLM_MODEL = os.getenv("OLLAMA_LLM_MODEL", "phi3")
OLLAMA_EMB_MODEL = os.getenv("OLLAMA_EMB_MODEL", "nomic-embed-text")
OLLAMA_TIMEOUT   = int(os.getenv("OLLAMA_TIMEOUT", "120"))

# ── FastAPI server ─────────────────────────────────────────────────────────
API_HOST   = os.getenv("API_HOST",   "0.0.0.0")
API_PORT   = int(os.getenv("API_PORT", "8000"))
API_RELOAD = os.getenv("API_RELOAD", "true").lower() == "true"

# ── File uploads ───────────────────────────────────────────────────────────
MAX_UPLOAD_SIZE_MB = int(os.getenv("MAX_UPLOAD_SIZE_MB", "10"))
ALLOWED_EXTENSIONS = {".pdf", ".docx"}

# ── ChromaDB (local persistent store) ─────────────────────────────────────
CHROMA_PERSIST_PATH = str(VECTOR_STORE_DIR)
