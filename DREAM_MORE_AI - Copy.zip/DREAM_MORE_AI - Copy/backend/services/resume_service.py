# backend/services/resume_service.py
# Extracts and cleans text from PDF / DOCX resumes.
# Uses PyMuPDF and python-docx — fully local, no external APIs.

import io
import re

import fitz          # PyMuPDF
from docx import Document
from fastapi import UploadFile

from backend.workers.ocr_worker import needs_ocr, extract_text_with_ocr


async def extract_text_from_resume(file: UploadFile) -> str:
    """
    Extract raw text from a PDF or DOCX resume upload.

    For PDFs: uses PyMuPDF first. If the PDF is scanned (image-based),
    falls back to OCR via Tesseract (if installed).
    Returns cleaned, normalised plain text ready for RAG chunking.
    """
    contents = await file.read()
    filename = (file.filename or "").lower()

    if filename.endswith(".pdf"):
        text = _extract_pdf(contents)
    elif filename.endswith(".docx"):
        text = _extract_docx(contents)
    else:
        raise ValueError(
            f"Unsupported file type. Only PDF and DOCX are accepted."
        )

    cleaned = clean_resume_text(text)

    # OCR fallback for scanned / image-only PDFs
    if not cleaned and filename.endswith(".pdf") and needs_ocr(contents):
        print("⚠️  PDF has no selectable text — trying OCR fallback...")
        ocr_text = extract_text_with_ocr(contents)
        cleaned  = clean_resume_text(ocr_text)

    if not cleaned:
        raise ValueError(
            "No readable text could be extracted from the file. "
            "Ensure the PDF is not password-protected or corrupted."
        )

    return cleaned


def _extract_pdf(contents: bytes) -> str:
    text = ""
    pdf = fitz.open(stream=contents, filetype="pdf")
    for page in pdf:
        text += page.get_text()
    pdf.close()
    return text


def _extract_docx(contents: bytes) -> str:
    doc = Document(io.BytesIO(contents))
    return "\n".join(para.text for para in doc.paragraphs)


def clean_resume_text(text: str) -> str:
    """
    Normalise extracted resume text:
    - Collapse all whitespace to single spaces
    - Remove page number artefacts
    - Strip leading/trailing whitespace
    """
    text = re.sub(r"\s+", " ", text)
    text = re.sub(r"\bPage\s+\d+\b", "", text, flags=re.IGNORECASE)
    return text.strip()


def detect_sections(text: str) -> dict:
    """
    Detect common resume sections by keyword matching.
    Returns {section_name: section_text}.
    """
    patterns = {
        "summary":    r"(summary|objective|profile|about\s+me)[:\n]",
        "skills":     r"(skills|technical\s+skills|core\s+competencies)[:\n]",
        "experience": r"(experience|work\s+history|employment\s+history)[:\n]",
        "education":  r"(education|academic\s+background|qualifications)[:\n]",
        "projects":   r"(projects|portfolio|personal\s+projects)[:\n]",
    }

    sections: dict = {}
    for name, pattern in patterns.items():
        match = re.search(pattern, text, flags=re.IGNORECASE)
        if not match:
            continue
        start = match.end()
        # Find the nearest following section header
        next_starts = [
            m.start()
            for n2, p2 in patterns.items()
            if n2 != name
            for m in [re.search(p2, text[start:], flags=re.IGNORECASE)]
            if m
        ]
        end = start + min(next_starts) if next_starts else len(text)
        sections[name] = text[start:end].strip()

    return sections
