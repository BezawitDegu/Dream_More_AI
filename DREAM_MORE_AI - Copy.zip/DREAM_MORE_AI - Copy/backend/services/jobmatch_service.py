# backend/services/jobmatch_service.py
# RAG-based job-description matching — fully local, no external APIs.

import uuid

from backend.ai.rag_pipeline import (
    chunk_job_text,
    store_job_chunks,
    retrieve_resume_chunks,
    retrieve_job_chunks,
)
from backend.ai.prompt_builder import build_job_match_prompt
from backend.ai.ollama_client import run_analysis
from backend.ai.scoring import score_label
from backend.database.seed_kb import retrieve_resume_context


def match_resume_to_job(resume_id: str, job_description: str) -> dict:
    """
    RAG job-match pipeline — grounded in Dream More hiring standards.
    1. Chunk + embed job description into ChromaDB
    2. Retrieve relevant resume chunks
    3. Retrieve relevant job chunks
    4. Inject Dream More hiring standards from resume KB
    5. Run LLM analysis locally
    """
    if not job_description.strip():
        return {"error": "Job description cannot be empty."}

    # Index job description
    job_id     = f"job_{resume_id}_{uuid.uuid4().hex[:8]}"
    job_chunks = chunk_job_text(job_description, job_id)
    store_job_chunks(job_chunks)

    # Retrieve resume chunks relevant to this job
    resume_chunks = retrieve_resume_chunks(
        job_description, top_k=4, resume_id=resume_id
    )
    if not resume_chunks:
        return {
            "error": (
                "No resume data found. "
                "Please upload a resume before running a job match."
            )
        }

    # Retrieve top job chunks
    retrieved_job_chunks = retrieve_job_chunks(job_description, top_k=3)

    # Get Dream More hiring standards context
    company_context = retrieve_resume_context(job_description, top_k=1)

    # Build prompt with company context
    prompt = build_job_match_prompt(resume_chunks, retrieved_job_chunks)
    if company_context:
        prompt["context"] += f"\n\n=== DREAM MORE STANDARDS ===\n{company_context}"

    analysis = run_analysis(prompt)

    if "error" in analysis:
        return analysis

    match_score = float(analysis.get("match_score", 0))

    return {
        "resume_id":        resume_id,
        "match_score":      match_score,
        "label":            score_label(match_score),
        "skills_match":     analysis.get("skills_match",     []),
        "skills_gap":       analysis.get("skills_gap",       []),
        "experience_match": analysis.get("experience_match", 0),
        "strengths":        analysis.get("strengths",        []),
        "weaknesses":       analysis.get("weaknesses",       []),
        "suggestions":      analysis.get("suggestions",      []),
    }
