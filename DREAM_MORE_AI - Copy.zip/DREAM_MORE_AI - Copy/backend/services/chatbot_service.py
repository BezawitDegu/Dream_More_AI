# backend/services/chatbot_service.py
# Student Chatbot — retrieves Dream More company KB on EVERY message.
# Critical company facts are ALWAYS in the system prompt — never truncated.

from backend.ai.ollama_client import run_chat
from backend.ai.rag_pipeline import retrieve_resume_chunks
from backend.database.seed_kb import retrieve_company_context
from backend.repositories.resume_repository import get_resume

_sessions: dict = {}
MAX_HISTORY = 4


def get_or_create_session(session_id: str) -> list:
    if session_id not in _sessions:
        _sessions[session_id] = []
    return _sessions[session_id]


def chat(session_id: str, user_message: str, resume_id: str = None) -> dict:
    if not user_message.strip():
        return {"session_id": session_id, "reply": "Please type a message.",
                "turn": 0, "history_length": 0}

    # Retrieve company KB context
    company_context = retrieve_company_context(user_message, top_k=2)

    # Optionally retrieve resume chunks
    resume_chunks = []
    if resume_id and resume_id.strip():
        meta = get_resume(resume_id.strip())
        if meta:
            resume_chunks = retrieve_resume_chunks(
                user_message, top_k=2, resume_id=resume_id.strip()
            )

    # Build system prompt
    system_prompt = _build_system_prompt(company_context, resume_chunks)

    # Run LLM
    history  = get_or_create_session(session_id)
    messages = list(history) + [{"role": "user", "content": user_message}]
    reply    = run_chat(system_prompt, messages)

    # Save history
    history.append({"role": "user",      "content": user_message})
    history.append({"role": "assistant", "content": reply})
    if len(history) > MAX_HISTORY:
        _sessions[session_id] = history[-MAX_HISTORY:]

    return {
        "session_id":     session_id,
        "reply":          reply,
        "turn":           len(_sessions[session_id]) // 2,
        "history_length": len(_sessions[session_id]),
        "resume_rag":     bool(resume_chunks),
    }


def _build_system_prompt(company_context: str, resume_chunks: list) -> str:
    """
    Build system prompt — critical facts are ALWAYS at the top
    so they are never cut off by context window truncation.
    """
    prompt = (
        "You are DreamBot, the official AI assistant for Dream More Digitals.\n\n"
        "CRITICAL FACTS — use ONLY these, NEVER invent different ones:\n"
        "- Location: Signal Mall, 8th Floor, Bahir Dar, Ethiopia\n"
        "- Email: suport@dreammoredigitals.com\n"
        "- Phone/WhatsApp: +251 993 132 122\n"
        "- Telegram: @Dreammore21\n"
        "- Website: https://www.dreammoredigitals.com\n"
        "- Hours: Mon-Fri 2AM-11AM, Sat 4AM-10AM, Sun Closed\n"
        "- Academy: 16+ courses, 150+ students, 98% job placement\n"
        "- Services: Software Dev, Brand Identity, Digital Marketing, UI/UX\n\n"
        "RULES: Answer from the facts above. Be short and direct. "
        "NEVER say 'I don't have information' if the answer is above.\n\n"
    )

    if company_context:
        prompt += f"ADDITIONAL CONTEXT:\n{company_context[:500]}\n\n"

    if resume_chunks:
        resume_text = "\n".join(c["text"] for c in resume_chunks)[:300]
        prompt += f"STUDENT RESUME:\n{resume_text}\n"

    return prompt


def get_history(session_id: str) -> list:
    return _sessions.get(session_id, [])


def clear_session(session_id: str) -> dict:
    existed = session_id in _sessions
    _sessions.pop(session_id, None)
    return {
        "session_id": session_id,
        "cleared":    existed,
        "message":    "Conversation cleared." if existed else "No session found.",
    }


def list_sessions() -> list:
    return [
        {"session_id": sid, "turns": len(hist) // 2}
        for sid, hist in _sessions.items()
    ]
