# backend/services/learning_path_service.py
# Learning Path Recommender — grounded in Dream More student support KB.
# 100% local: Ollama. Zero cost.

from backend.ai.prompt_builder import build_learning_path_prompt
from backend.ai.ollama_client import run_learning_path
from backend.database.seed_kb import retrieve_student_context


def generate_learning_path(
    goal: str,
    current_skills: list,
    education_level: str,
    duration_weeks: int = 12,
) -> dict:
    """
    Generate a personalised learning path using LLaMA3 (local).
    Retrieves Dream More student support KB to ground the recommendations
    in Dream More Academy courses and career paths.
    """
    if not goal.strip():
        return {"error": "Career goal cannot be empty."}
    if duration_weeks < 1 or duration_weeks > 104:
        return {"error": "Duration must be between 1 and 104 weeks."}

    skills = [s.strip() for s in current_skills if s.strip()]

    # Retrieve relevant Dream More student support context
    student_context = retrieve_student_context(goal, top_k=1)

    # Build prompt with Dream More KB injected
    prompt = build_learning_path_prompt(
        goal=goal,
        current_skills=skills,
        education_level=education_level,
        duration_weeks=duration_weeks,
        company_context=student_context,
    )

    result = run_learning_path(prompt)

    if "error" in result:
        return result

    return {
        "title":           result.get("title",           f"Learning Path: {goal}"),
        "goal":            goal,
        "total_weeks":     result.get("total_weeks",     duration_weeks),
        "phases":          result.get("phases",          []),
        "skills_gained":   result.get("skills_gained",   []),
        "career_outcomes": result.get("career_outcomes", []),
        "tips":            result.get("tips",            []),
    }
