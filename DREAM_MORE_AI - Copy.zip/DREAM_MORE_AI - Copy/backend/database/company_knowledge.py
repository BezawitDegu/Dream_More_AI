# backend/database/company_knowledge.py
# Complete Dream More Digitals knowledge base.
# Source: https://www.dreammoredigitals.com (all pages fetched)
# Used by: Chatbot KB, Resume KB, Student Support KB

# ══════════════════════════════════════════════════════════════
# CHATBOT KB — conversational Q&A about Dream More
# ══════════════════════════════════════════════════════════════
CHATBOT_KB = [
    {
        "id": "chat_location",
        "text": """
Q: Where is Dream More located?
A: Dream More Digitals is located at Signal Mall, 8th Floor, Bahir Dar, Ethiopia.

Q: What is the address of Dream More?
A: Signal Mall, 8th floor, Bahirdar, Ethiopia.

Q: Where is the Dream More office in Bahir Dar?
A: The Dream More office is at Signal Mall, 8th Floor, Bahir Dar, Ethiopia.

Q: How do I visit Dream More?
A: Go to Signal Mall in Bahir Dar and take the elevator to the 8th floor.
        """.strip(),
    },
    {
        "id": "chat_contact",
        "text": """
Q: How can I contact Dream More?
A: Contact Dream More Digitals through:
   Email: suport@dreammoredigitals.com
   Phone: +251 993 132 122
   WhatsApp: +251 993 132 122
   Telegram: @Dreammore21
   Website: https://www.dreammoredigitals.com
   Address: Signal Mall, 8th Floor, Bahir Dar, Ethiopia

Q: What is Dream More phone number?
A: +251 993 132 122

Q: What is Dream More email address?
A: suport@dreammoredigitals.com

Q: What is Dream More Telegram?
A: @Dreammore21

Q: What are Dream More business hours?
A: Monday to Friday: 2:00 AM to 11:00 AM
   Saturday: 4:00 AM to 10:00 AM
   Sunday: Closed
        """.strip(),
    },
    {
        "id": "chat_about",
        "text": """
Q: What is Dream More Digitals?
A: Dream More Digitals is an Award-Winning Digital Innovation Ecosystem based in
   Bahir Dar, Ethiopia. It empowers Africa's digital future by combining a
   world-class agency with a training academy under one roof.

Q: What does Dream More do?
A: Dream More builds world-class digital products for clients (agency) and
   trains students in 16+ digital skills (academy).

Q: What is Dream More's mission?
A: To deliver outstanding services tailored to the unique needs of each client,
   ensuring quality, efficiency, and innovation in every aspect of work.

Q: What are Dream More's values?
A: Excellence, innovation, and social impact. Dream More is committed to
   delivering high-quality services and empowering Africa's digital future.

Q: What is Dream More's tagline?
A: Empowering Africa's Digital Future.

Q: What are Dream More's achievements?
A: Award Winning Agency, 150+ Students Trained, 98% Success Rate,
   30+ Projects Delivered, 4.9 Star Client Rating, 3x Average ROI Uplift,
   50+ Happy Clients, 98% Client Satisfaction Rate.
        """.strip(),
    },
    {
        "id": "chat_agency_services",
        "text": """
Q: What agency services does Dream More offer?
A: Dream More Agency offers four main services:
   1. Software Development - Scalable web and mobile apps, AI-powered platforms,
      enterprise software, production-ready solutions at global scale.
   2. Brand Identity - Visual storytelling and strategy, logo design,
      brand guidelines, brand strategy.
   3. Digital Marketing - SEO, social media growth, content marketing,
      online advertising campaigns.
   4. UI/UX Design - User-centric experiences, wireframing, prototyping,
      interface design for web and mobile.

Q: Does Dream More build mobile apps?
A: Yes. Dream More builds scalable web and mobile apps for clients.

Q: Does Dream More do SEO?
A: Yes. Dream More offers SEO and social media growth as part of digital marketing.

Q: How many projects has Dream More delivered?
A: Dream More has delivered 30+ projects with a 4.9 star client rating.

Q: What is Dream More's ROI for clients?
A: Dream More delivers 3x average ROI uplift for its clients.
        """.strip(),
    },
    {
        "id": "chat_academy",
        "text": """
Q: What is Dream More Academy?
A: Dream More Academy is the TeachMaster program that teaches 16+ in-demand
   digital skills. Students learn from industry professionals through
   real-world projects and get certified to launch careers in tech.

Q: How many courses does Dream More Academy have?
A: Dream More Academy offers 16+ in-demand digital skills courses.

Q: What is Dream More's job placement rate?
A: 98% job placement rate for Dream More Academy graduates.

Q: How many students has Dream More trained?
A: 150+ students trained and certified.

Q: Are Dream More Academy graduates certified?
A: Yes. 100% of Dream More Academy graduates receive certification.

Q: Why is Dream More Academy different from other schools?
A: Dream More teaches real-world curriculum — the exact stacks and workflows
   used daily for global agency clients, not outdated textbooks.
   Instructors are active practitioners building products for global brands.
   Graduates are pre-vetted, cutting-edge, and job-ready.

Q: How do I enroll in Dream More Academy?
A: Contact Dream More at suport@dreammoredigitals.com or WhatsApp +251 993 132 122
   or visit Signal Mall, 8th Floor, Bahir Dar, Ethiopia.
        """.strip(),
    },
    {
        "id": "chat_courses",
        "text": """
Q: What courses does Dream More Academy offer?
A: Dream More Academy offers 16+ courses including:

   Technical Courses:
   - Web Development (HTML, CSS, JavaScript, React, Node.js)
   - Mobile App Development (Android, iOS, Flutter)
   - Software Engineering and Architecture
   - Artificial Intelligence and Machine Learning
   - Data Science and Analytics
   - Backend Development (Python, Django, FastAPI, Node.js)
   - Database Management (SQL, MongoDB, PostgreSQL)
   - Cloud Computing (AWS, Azure, Google Cloud)
   - Cybersecurity and Ethical Hacking

   Creative and Business Courses:
   - UI/UX Design (Figma, Adobe XD)
   - Graphic Design and Brand Identity
   - Digital Marketing and SEO
   - Social Media Management and Growth
   - Content Creation and Strategy
   - Video Editing and Production
   - Project Management (Agile, Scrum)

Q: Does Dream More teach Python?
A: Yes. Python is taught in Backend Development, Data Science, and AI courses.

Q: Does Dream More teach AI?
A: Yes. Dream More Academy offers Artificial Intelligence and Machine Learning courses.

Q: Does Dream More teach web development?
A: Yes. Web Development is one of the core courses at Dream More Academy.
        """.strip(),
    },
    {
        "id": "chat_pricing",
        "text": """
Q: How much do Dream More courses cost?
A: Dream More Academy offers affordable and flexible pricing.
   Exact fees depend on the specific course and duration.
   Contact for current prices:
   Email: suport@dreammoredigitals.com
   WhatsApp: +251 993 132 122
   Telegram: @Dreammore21

Q: Does Dream More offer payment installments?
A: Yes. Dream More offers payment installments for qualifying students.

Q: Does Dream More offer scholarships?
A: Yes. Dream More offers scholarships for outstanding students.

Q: Does Dream More offer group discounts?
A: Yes. Dream More offers group discounts for organizations and companies.

Q: How much does a software project cost at Dream More?
A: Agency project costs are custom-quoted based on scope and complexity.
   Contact suport@dreammoredigitals.com for a free consultation and quote.
        """.strip(),
    },
    {
        "id": "chat_ecosystem",
        "text": """
Q: What is the Dream More ecosystem advantage?
A: Dream More operates two power centers:
   1. The Agency — builds world-class digital products for clients
   2. The Academy — trains the next generation of digital professionals

   Agency insights feed the Academy curriculum.
   Academy talent powers the Agency's client work.
   This creates a unique ecosystem where students learn real skills
   and clients get access to cutting-edge talent.

Q: Who are Dream More instructors?
A: Dream More instructors are senior developers, designers, and marketers
   who are actively building products for global brands.
   They teach what they do every day — not outdated textbooks.

Q: What is the Dream More talent pipeline?
A: Dream More graduates are pre-vetted, cutting-edge, and job-ready.
   Clients benefit from a continuously trained talent pool.
        """.strip(),
    },
    {
        "id": "chat_internship",
        "text": """
Q: Does Dream More offer internships?
A: Yes. Dream More Digitals offers internships in Software Development,
   AI/ML, UI/UX Design, Digital Marketing, and Data Science.

Q: How do I apply for a Dream More internship?
A: Email suport@dreammoredigitals.com or WhatsApp +251 993 132 122
   or visit Signal Mall, 8th Floor, Bahir Dar, Ethiopia.

Q: Who built Dream More AI?
A: DREAM MORE AI was built by Bezawit Degu, a 4th year Computer Science
   student at University of Gondar, during her internship at Dream More Digitals.

Q: What is Dream More AI?
A: DREAM MORE AI is an AI-powered student platform with three modules:
   Resume Analyzer, Student Chatbot (DreamBot), and Learning Path Recommender.
   Built by intern Bezawit Degu using LLaMA3, ChromaDB, and FastAPI.
        """.strip(),
    },
    {
        "id": "chat_testimonials",
        "text": """
Q: What do clients say about Dream More?
A: Dream More has a 4.9 star average rating from 50+ happy clients
   with 98% client satisfaction rate.
   Real stories from businesses and individuals who have partnered with
   Dream More to achieve their digital goals.

Q: How many clients does Dream More have?
A: Dream More has 50+ happy clients with 98% satisfaction rate.

Q: What is Dream More's client rating?
A: Dream More has a 4.9 star client rating.
        """.strip(),
    },
]


# ══════════════════════════════════════════════════════════════
# RESUME KB — job roles, skills, hiring standards at Dream More
# ══════════════════════════════════════════════════════════════
RESUME_KB = [
    {
        "id": "resume_roles",
        "text": """
Dream More Digitals Job Roles and Required Skills:

Software Developer:
Required: Python, JavaScript, React, Node.js, REST APIs, Git, SQL/NoSQL,
problem solving, teamwork, communication.
Preferred: AI/ML experience, mobile development, cloud services (AWS/Azure).

UI/UX Designer:
Required: Figma, Adobe XD, wireframing, prototyping, user research,
visual design, HTML/CSS basics, creativity, communication.
Preferred: motion design, design systems, accessibility knowledge.

Digital Marketing Specialist:
Required: SEO, Google Analytics, social media management, content writing,
Facebook/Instagram ads, email marketing, data analysis, creativity.
Preferred: Google Ads certification, video marketing, influencer marketing.

Brand Identity Designer:
Required: Adobe Illustrator, Photoshop, typography, color theory,
brand strategy, logo design, creative thinking, attention to detail.

Data Scientist / AI Engineer:
Required: Python, machine learning, deep learning, pandas, numpy,
scikit-learn, TensorFlow or PyTorch, data visualization, statistics.
Preferred: NLP, computer vision, LLMs, RAG pipelines, ChromaDB.

Project Manager:
Required: Agile, Scrum, communication, leadership, risk management,
stakeholder management, problem solving, MS Project or Jira.
        """.strip(),
    },
    {
        "id": "resume_standards",
        "text": """
Dream More Digitals Hiring Standards and Resume Requirements:

What Dream More looks for:
1. Real-world project experience — portfolio of completed projects
2. Ability to work in a fast-paced startup/agency environment
3. Passion for technology, innovation, and continuous learning
4. Strong communication and teamwork skills
5. Self-learner who keeps up with latest tech trends
6. Impact-driven — show what you built and what problem it solved

Resume Tips for Dream More Applications:
- Highlight real projects with GitHub links or live demos
- Mention specific technologies, tools, and frameworks used
- Show measurable impact: users served, performance improvements, etc.
- Keep resume clean, well-formatted, ATS-friendly, under 2 pages
- Tailor your resume to the specific role you are applying for
- Include a professional summary that matches Dream More's mission
- List certifications, especially from Dream More Academy

Common Resume Mistakes to Avoid:
- Listing skills you don't actually have
- Using generic descriptions without specific examples
- Poor formatting that fails ATS screening
- No portfolio or GitHub link for developers/designers
- Missing contact information or LinkedIn profile
        """.strip(),
    },
    {
        "id": "resume_keywords",
        "text": """
ATS Keywords for Dream More Digitals Job Applications:

Software Development:
Python, JavaScript, TypeScript, React, React Native, Node.js, FastAPI,
Django, REST API, GraphQL, Git, GitHub, Docker, AWS, MongoDB, PostgreSQL,
MySQL, Agile, Scrum, CI/CD, Unit Testing, Microservices.

Digital Marketing:
SEO, SEM, Google Analytics, Google Ads, Facebook Ads, Instagram Marketing,
Content Marketing, Email Marketing, Social Media Management, Brand Strategy,
KPI, ROI, Conversion Rate Optimization, A/B Testing, Copywriting.

UI/UX Design:
Figma, Adobe XD, Sketch, User Research, Wireframing, Prototyping,
User Testing, Information Architecture, Accessibility, Responsive Design,
Design Systems, Typography, Color Theory.

AI/ML Engineering:
Machine Learning, Deep Learning, Neural Networks, Python, TensorFlow,
PyTorch, Scikit-learn, Data Analysis, NLP, Computer Vision, RAG, LLM,
ChromaDB, Ollama, LLaMA, Vector Databases, Embeddings.

General (Dream More Values):
Innovation, Problem Solving, Teamwork, Communication, Project Management,
Client-Centered, Quality, Efficiency, Real-World Projects, Portfolio,
Leadership, Creativity, Attention to Detail, Fast Learner.
        """.strip(),
    },
]


# ══════════════════════════════════════════════════════════════
# STUDENT SUPPORT KB — courses, academy, career guidance
# ══════════════════════════════════════════════════════════════
STUDENT_SUPPORT_KB = [
    {
        "id": "student_courses_guide",
        "text": """
Dream More Academy Course Guide for Students:

Beginner Level (0 experience):
- Web Development Fundamentals (HTML, CSS, JavaScript)
- Graphic Design Basics (Adobe tools, color theory)
- Digital Marketing Introduction
- Computer Fundamentals and Office Tools

Intermediate Level (some experience):
- React and Node.js Full Stack Development
- Python Programming for Data and Web
- UI/UX Design with Figma
- Social Media Marketing and SEO Mastery
- Database Management (SQL and NoSQL)
- Mobile App Development Basics

Advanced Level (experienced):
- Artificial Intelligence and Machine Learning
- Full Stack Web Development (React + Node + MongoDB)
- Data Science and Analytics
- Cloud Computing (AWS/Azure)
- Cybersecurity and Ethical Hacking
- Advanced Digital Marketing and Growth Hacking

To enroll in any course:
Email: suport@dreammoredigitals.com
WhatsApp: +251 993 132 122
Visit: Signal Mall, 8th Floor, Bahir Dar, Ethiopia
        """.strip(),
    },
    {
        "id": "student_career_paths",
        "text": """
Career Paths Available After Dream More Academy Training:

Path 1 — Software Developer:
Learn: Web Development → Python → Full Stack → API Development
Career: Junior Developer → Mid-Level Developer → Senior Developer → Tech Lead

Path 2 — AI/ML Engineer:
Learn: Python → Data Science → Machine Learning → Deep Learning → AI Applications
Career: Data Analyst → ML Engineer → AI Engineer → AI Research Lead

Path 3 — UI/UX Designer:
Learn: Graphic Design → Figma → User Research → Prototyping → Design Systems
Career: Junior Designer → UI/UX Designer → Senior Designer → Design Lead

Path 4 — Digital Marketer:
Learn: Digital Marketing → SEO → Social Media → Paid Ads → Analytics
Career: Marketing Assistant → Digital Marketer → Marketing Manager → CMO

Path 5 — Brand Designer:
Learn: Graphic Design → Brand Identity → Adobe Suite → Brand Strategy
Career: Junior Designer → Brand Designer → Creative Director

Path 6 — Data Scientist:
Learn: Python → Statistics → Machine Learning → Data Visualization → Big Data
Career: Data Analyst → Data Scientist → Senior Data Scientist → Data Lead

Dream More has 98% job placement rate for all career paths.
Contact: suport@dreammoredigitals.com | +251 993 132 122
        """.strip(),
    },
    {
        "id": "student_learning_paths",
        "text": """
Recommended Learning Paths at Dream More Academy:

Become a Full Stack Developer (16 weeks):
Week 1-4: HTML, CSS, JavaScript fundamentals
Week 5-8: React frontend development
Week 9-12: Node.js and Python backend
Week 13-16: Databases, REST APIs, deployment
Milestone: Build and deploy a full web application

Become an AI Engineer (20 weeks):
Week 1-4: Python fundamentals
Week 5-8: Data Science and statistics
Week 9-12: Machine Learning algorithms
Week 13-16: Deep Learning and Neural Networks
Week 17-20: LLMs, RAG pipelines, AI applications
Milestone: Build an AI-powered application

Become a Digital Marketer (12 weeks):
Week 1-3: Digital marketing fundamentals
Week 4-6: SEO and content marketing
Week 7-9: Social media and paid advertising
Week 10-12: Analytics, reporting, strategy
Milestone: Run a complete digital marketing campaign

Become a UI/UX Designer (12 weeks):
Week 1-3: Design principles, Figma tools
Week 4-6: User research and wireframing
Week 7-9: Prototyping and user testing
Week 10-12: Portfolio and real client projects
Milestone: Design a complete app interface with user research

All paths taught by active industry practitioners.
98% job placement rate. 100% certification.
Contact: suport@dreammoredigitals.com | +251 993 132 122
        """.strip(),
    },
    {
        "id": "student_support_resources",
        "text": """
Dream More Student Support and Resources:

How Dream More supports students:
- Learn from senior developers and marketers active in industry
- Real-world curriculum based on actual client projects
- Certification upon course completion (100% certified)
- Career placement support with 98% success rate
- Access to Dream More talent pipeline — pre-vetted and job-ready
- Mentorship from active practitioners
- Community of fellow students and professionals

Interview Preparation Tips from Dream More:
- Build a portfolio of real projects during your course
- Practice explaining your projects clearly in interviews
- Know your tools and technologies deeply — not just surface level
- Be ready to solve problems live in technical interviews
- Highlight real-world project experience over theoretical knowledge
- Show your passion for continuous learning and innovation
- Research the company before the interview

Resume Tips for Students:
- Highlight Dream More Academy certification
- List all real projects built during the course
- Include GitHub link or portfolio website
- Show measurable impact of your projects
- Tailor each resume to the specific job description
- Keep it clean, professional, and under 2 pages

For student support:
Email: suport@dreammoredigitals.com
WhatsApp: +251 993 132 122
Telegram: @Dreammore21
Visit: Signal Mall, 8th Floor, Bahir Dar, Ethiopia
        """.strip(),
    },
    {
        "id": "student_faq",
        "text": """
Student Frequently Asked Questions:

Q: How long do Dream More courses take?
A: Courses range from 8 to 20 weeks depending on the topic and level.

Q: Can I learn online or only in person?
A: Contact Dream More at suport@dreammoredigitals.com for current delivery options.

Q: Do I get a certificate after completing a course?
A: Yes. 100% of Dream More Academy graduates receive certification.

Q: What is the job placement rate?
A: 98% job placement rate for Dream More Academy graduates.

Q: How much do courses cost?
A: Pricing varies by course. Contact suport@dreammoredigitals.com for current prices.
   Scholarships, installments, and group discounts are available.

Q: Can I switch careers using Dream More training?
A: Yes. Dream More has helped 150+ students switch careers and get placed in tech jobs.

Q: What makes Dream More Academy different?
A: Instructors are active practitioners. Curriculum is based on real client work.
   Graduates are pre-vetted and job-ready through the Dream More talent pipeline.

Q: How do I enroll?
A: Email suport@dreammoredigitals.com or WhatsApp +251 993 132 122
   or visit Signal Mall, 8th Floor, Bahir Dar, Ethiopia.
        """.strip(),
    },
]
