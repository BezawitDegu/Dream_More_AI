# backend/database/chroma_db.py
# Local ChromaDB persistent vector store.
# Singleton client — one connection shared across the whole app.

from typing import Optional
import chromadb
from backend.config.settings import CHROMA_PERSIST_PATH

_client: Optional[chromadb.PersistentClient] = None


def get_chroma_client() -> chromadb.PersistentClient:
    """Return (and lazily create) the singleton ChromaDB client."""
    global _client
    if _client is None:
        _client = chromadb.PersistentClient(path=CHROMA_PERSIST_PATH)
    return _client


def get_resume_collection():
    """Collection for resume chunk embeddings (cosine similarity)."""
    return get_chroma_client().get_or_create_collection(
        name="resumes",
        metadata={"hnsw:space": "cosine"},
    )


def get_jobs_collection():
    """Collection for job description embeddings (cosine similarity)."""
    return get_chroma_client().get_or_create_collection(
        name="jobs",
        metadata={"hnsw:space": "cosine"},
    )


def get_company_kb_collection():
    """General company KB — used by all modules."""
    return get_chroma_client().get_or_create_collection(
        name="company_kb",
        metadata={"hnsw:space": "cosine"},
    )


def get_chatbot_kb_collection():
    """Chatbot-specific KB — conversational Q&A about Dream More."""
    return get_chroma_client().get_or_create_collection(
        name="chatbot_kb",
        metadata={"hnsw:space": "cosine"},
    )


def get_resume_kb_collection():
    """Resume analyzer KB — job roles, skills, hiring standards at Dream More."""
    return get_chroma_client().get_or_create_collection(
        name="resume_kb",
        metadata={"hnsw:space": "cosine"},
    )


def get_student_support_kb_collection():
    """Student support KB — courses, academy, career guidance at Dream More."""
    return get_chroma_client().get_or_create_collection(
        name="student_support_kb",
        metadata={"hnsw:space": "cosine"},
    )


def reset_collection(name: str) -> None:
    """
    Delete and recreate a collection — useful for testing / data resets.
    WARNING: destroys all stored embeddings for that collection.
    """
    client = get_chroma_client()
    try:
        client.delete_collection(name)
    except Exception:
        pass
    client.create_collection(name, metadata={"hnsw:space": "cosine"})
