# backend/database/seed_kb.py
# Seeds all 3 Dream More knowledge bases into ChromaDB.
# Run: py -m backend.database.seed_kb

from langchain_text_splitters import RecursiveCharacterTextSplitter
from backend.database.chroma_db import (
    get_company_kb_collection,
    get_chatbot_kb_collection,
    get_resume_kb_collection,
    get_student_support_kb_collection,
)
from backend.ai.ollama_client import generate_embedding
from backend.database.company_knowledge import CHATBOT_KB, RESUME_KB, STUDENT_SUPPORT_KB

splitter = RecursiveCharacterTextSplitter(
    chunk_size=300,
    chunk_overlap=40,
    length_function=len,
)


def _seed_collection(collection, entries: list, label: str) -> int:
    """Embed and upsert entries into a ChromaDB collection."""
    total = 0
    for entry in entries:
        chunks = splitter.split_text(entry["text"])
        for i, chunk in enumerate(chunks):
            chunk_id = f"{entry['id']}_chunk_{i}"
            embedding = generate_embedding(chunk)
            collection.upsert(
                ids=[chunk_id],
                documents=[chunk],
                embeddings=[embedding],
                metadatas=[{"source_id": entry["id"], "chunk_index": i}],
            )
            total += 1
    print(f"  ✅ {label}: {len(entries)} entries → {total} chunks")
    return total


def seed_all(force: bool = True):
    """Seed all 3 knowledge base collections."""
    print("🔄 Seeding Dream More knowledge bases...")

    # 1. Chatbot KB
    chatbot_col = get_chatbot_kb_collection()
    if force:
        try:
            from backend.database.chroma_db import get_chroma_client
            get_chroma_client().delete_collection("chatbot_kb")
            chatbot_col = get_chatbot_kb_collection()
        except Exception:
            pass
    _seed_collection(chatbot_col, CHATBOT_KB, "Chatbot KB")

    # 2. Resume KB
    resume_col = get_resume_kb_collection()
    if force:
        try:
            from backend.database.chroma_db import get_chroma_client
            get_chroma_client().delete_collection("resume_kb")
            resume_col = get_resume_kb_collection()
        except Exception:
            pass
    _seed_collection(resume_col, RESUME_KB, "Resume KB")

    # 3. Student Support KB
    student_col = get_student_support_kb_collection()
    if force:
        try:
            from backend.database.chroma_db import get_chroma_client
            get_chroma_client().delete_collection("student_support_kb")
            student_col = get_student_support_kb_collection()
        except Exception:
            pass
    _seed_collection(student_col, STUDENT_SUPPORT_KB, "Student Support KB")

    # 4. Also seed general company KB (used as fallback)
    company_col = get_company_kb_collection()
    if force:
        try:
            from backend.database.chroma_db import get_chroma_client
            get_chroma_client().delete_collection("company_kb")
            company_col = get_company_kb_collection()
        except Exception:
            pass
    all_entries = CHATBOT_KB + RESUME_KB + STUDENT_SUPPORT_KB
    _seed_collection(company_col, all_entries, "General Company KB")

    print("✅ All knowledge bases seeded successfully!")


def retrieve_company_context(query: str, top_k: int = 3) -> str:
    """Retrieve from general company KB — used by chatbot."""
    collection = get_chatbot_kb_collection()
    count = collection.count()
    if count == 0:
        return ""
    n = min(top_k, count)
    embedding = generate_embedding(query)
    results = collection.query(
        query_embeddings=[embedding],
        n_results=n,
        include=["documents"],
    )
    docs = results.get("documents", [[]])[0]
    return "\n\n".join(docs)


def retrieve_resume_context(query: str, top_k: int = 2) -> str:
    """Retrieve from resume KB — used by resume analyzer."""
    collection = get_resume_kb_collection()
    count = collection.count()
    if count == 0:
        return ""
    n = min(top_k, count)
    embedding = generate_embedding(query)
    results = collection.query(
        query_embeddings=[embedding],
        n_results=n,
        include=["documents"],
    )
    docs = results.get("documents", [[]])[0]
    return "\n\n".join(docs)


def retrieve_student_context(query: str, top_k: int = 2) -> str:
    """Retrieve from student support KB — used by learning path."""
    collection = get_student_support_kb_collection()
    count = collection.count()
    if count == 0:
        return ""
    n = min(top_k, count)
    embedding = generate_embedding(query)
    results = collection.query(
        query_embeddings=[embedding],
        n_results=n,
        include=["documents"],
    )
    docs = results.get("documents", [[]])[0]
    return "\n\n".join(docs)


if __name__ == "__main__":
    seed_all(force=True)
