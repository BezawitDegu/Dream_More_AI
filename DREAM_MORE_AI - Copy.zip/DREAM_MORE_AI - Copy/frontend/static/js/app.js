/* ═══════════════════════════════════════════════════════════════
   DREAM MORE AI — Resume Analyzer  |  app.js
   All API calls go to the local FastAPI backend (same origin).
   ═══════════════════════════════════════════════════════════════ */

const API = '';          // same origin — FastAPI serves both backend + frontend
let resumeId   = null;   // set after successful upload
let activeResumeFilename = null;
let lastChatRagChunks = 0;
let reportData = null;   // set after successful analysis

/* ── DOM refs ───────────────────────────────────────────────────── */
const $ = id => document.getElementById(id);

const dropZone       = $('drop-zone');
const fileInput      = $('file-input');
const filePreview    = $('file-preview');
const fileName       = $('file-name');
const clearFileBtn   = $('clear-file-btn');
const uploadBtn      = $('upload-btn');
const uploadResult   = $('upload-result');

const analyzeSection = document.querySelector('#analyze');
const analyzeBtn     = $('analyze-btn');

const matchSection   = document.querySelector('#match');
const jobDescInput   = $('job-desc-input');
const matchBtn       = $('match-btn');
const matchResult    = $('match-result');

const reportSection  = document.querySelector('#report');
const reportBtn      = $('report-btn');
const reportOutput   = $('report-output');
const downloadBtn    = $('download-btn');

const healthBadge    = $('health-badge');
const healthLabel    = healthBadge.querySelector('.health-label');
const toast          = $('toast');

/* ══════════════════════════════════════════════════════════════════
   HEALTH CHECK
   ══════════════════════════════════════════════════════════════════ */
async function checkHealth() {
  try {
    const res  = await fetch(`${API}/health`);
    const data = await res.json();
    if (data.ollama === 'ok') {
      setHealth('ok', 'Ollama connected');
    } else {
      setHealth('error', 'Ollama offline');
    }
  } catch {
    setHealth('error', 'API offline');
  }
}

function setHealth(status, label) {
  healthBadge.className = `health-badge ${status}`;
  healthLabel.textContent = label;
}

/* ══════════════════════════════════════════════════════════════════
   DRAG & DROP + FILE SELECTION
   ══════════════════════════════════════════════════════════════════ */
dropZone.addEventListener('click', () => fileInput.click());

dropZone.addEventListener('dragover', e => {
  e.preventDefault();
  dropZone.classList.add('drag-over');
});
dropZone.addEventListener('dragleave', () => dropZone.classList.remove('drag-over'));
dropZone.addEventListener('drop', e => {
  e.preventDefault();
  dropZone.classList.remove('drag-over');
  const file = e.dataTransfer.files[0];
  if (file) selectFile(file);
});

fileInput.addEventListener('change', () => {
  if (fileInput.files[0]) selectFile(fileInput.files[0]);
});

clearFileBtn.addEventListener('click', () => {
  fileInput.value = '';
  filePreview.classList.add('hidden');
  dropZone.classList.remove('hidden');
  uploadBtn.disabled = true;
  uploadResult.className = 'result-box hidden';
  uploadResult.textContent = '';
});

function selectFile(file) {
  const ext = file.name.split('.').pop().toLowerCase();
  if (!['pdf', 'docx'].includes(ext)) {
    showToast('Only PDF and DOCX files are supported.', 'error');
    return;
  }
  fileName.textContent = file.name;
  filePreview.classList.remove('hidden');
  dropZone.classList.add('hidden');
  uploadBtn.disabled = false;
}

/* ══════════════════════════════════════════════════════════════════
   STEP 1 — UPLOAD
   ══════════════════════════════════════════════════════════════════ */
uploadBtn.addEventListener('click', async () => {
  const file = fileInput.files[0];
  if (!file) return;

  setLoading(uploadBtn, true);
  uploadResult.className = 'result-box hidden';

  const form = new FormData();
  form.append('file', file);

  try {
    const res  = await fetch(`${API}/resume/upload`, { method: 'POST', body: form });
    const data = await res.json();

    if (!res.ok) {
      throw new Error(data.detail || 'Upload failed');
    }

    resumeId = data.resume_id;
    activeResumeFilename = data.filename || null;
    updateDreamBotResumeContext();

    uploadResult.className = 'result-box success';
    uploadResult.innerHTML =
      `✅ Uploaded successfully<br/>
       <small style="opacity:.7">ID: ${resumeId}</small><br/>
       <small style="opacity:.7">Chunks indexed: ${data.chunks}</small>`;

    // Unlock step 2 and 3
    unlock(analyzeSection);
    unlock(matchSection);
    analyzeBtn.disabled = false;
    matchBtn.disabled   = false;

    showToast('Resume uploaded and indexed!', 'success');
    loadResumeHistory();

  } catch (err) {
    uploadResult.className = 'result-box error';
    uploadResult.textContent = `❌ ${err.message}`;
    showToast(err.message, 'error');
  } finally {
    setLoading(uploadBtn, false);
  }
});

/* ══════════════════════════════════════════════════════════════════
   STEP 2 — ANALYZE
   ══════════════════════════════════════════════════════════════════ */
analyzeBtn.addEventListener('click', async () => {
  if (!resumeId) return;

  setLoading(analyzeBtn, true);
  hideAnalysisResults();

  try {
    const res  = await fetch(`${API}/resume/analyze/${resumeId}`, { method: 'POST' });
    const data = await res.json();

    if (!res.ok) throw new Error(data.detail || 'Analysis failed');

    reportData = data;

    renderScore(data.score, data.label);
    renderDimensions(data.analysis);
    renderInsights(data.analysis);

    // Unlock report section
    unlock(reportSection);
    reportBtn.disabled = false;

    showToast(`ATS Score: ${data.score} — ${data.label}`, 'success');
    loadResumeHistory();

  } catch (err) {
    showToast(`Analysis error: ${err.message}`, 'error');
  } finally {
    setLoading(analyzeBtn, false);
  }
});

/* ── Score ring ─────────────────────────────────────────────────── */
function renderScore(score, label) {
  // Inject SVG gradient once
  const svg = document.querySelector('.score-ring');
  if (!svg.querySelector('defs')) {
    svg.insertAdjacentHTML('afterbegin', `
      <defs>
        <linearGradient id="ringGradient" x1="0%" y1="0%" x2="100%" y2="0%">
          <stop offset="0%"   stop-color="#6c63ff"/>
          <stop offset="100%" stop-color="#a78bfa"/>
        </linearGradient>
      </defs>`);
  }

  const circumference = 2 * Math.PI * 52; // r=52 → ~327
  const offset = circumference - (score / 100) * circumference;

  $('score-value').textContent = score;
  const ring = $('ring-fill');
  ring.style.strokeDasharray  = circumference;
  ring.style.strokeDashoffset = circumference;         // start at 0
  ring.setAttribute('stroke', 'url(#ringGradient)');

  // Animate after paint
  requestAnimationFrame(() => {
    requestAnimationFrame(() => { ring.style.strokeDashoffset = offset; });
  });

  const labelEl = $('score-label');
  labelEl.textContent = label;
  labelEl.className   = `score-label ${labelClass(label)}`;

  $('score-section').classList.remove('hidden');
}

function labelClass(label) {
  const l = label.toLowerCase();
  if (l.includes('excellent'))          return 'excellent';
  if (l.includes('good'))               return 'good';
  if (l.includes('average'))            return 'average';
  return 'needs';
}

/* ── Dimension bars ─────────────────────────────────────────────── */
function renderDimensions(analysis) {
  const map = {
    ats:        ['bar-ats',    'val-ats'],
    skills:     ['bar-skills', 'val-skills'],
    experience: ['bar-exp',    'val-exp'],
    education:  ['bar-edu',    'val-edu'],
    formatting: ['bar-fmt',    'val-fmt'],
    grammar:    ['bar-gram',   'val-gram'],
  };
  const keys = {
    ats:        'ats_score',
    skills:     'skills_score',
    experience: 'experience_score',
    education:  'education_score',
    formatting: 'formatting_score',
    grammar:    'grammar_score',
  };

  for (const [dim, [barId, valId]] of Object.entries(map)) {
    const val = analysis[keys[dim]] ?? 0;
    $(valId).textContent = val;
    // Animate bar
    requestAnimationFrame(() => {
      requestAnimationFrame(() => { $(barId).style.width = `${val}%`; });
    });
  }
}

/* ── Insights ───────────────────────────────────────────────────── */
function renderInsights(analysis) {
  fillList('strengths-list',   analysis.strengths        || []);
  fillList('weaknesses-list',  analysis.weaknesses       || []);
  fillList('keywords-list',    analysis.missing_keywords || [], true);
  fillList('suggestions-list', analysis.suggestions      || []);
  $('insights-section').classList.remove('hidden');
}

function fillList(id, items, chips = false) {
  const ul = $(id);
  ul.innerHTML = '';
  if (!items.length) {
    ul.innerHTML = '<li>None identified</li>';
    return;
  }
  items.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    ul.appendChild(li);
  });
}

function hideAnalysisResults() {
  $('score-section').classList.add('hidden');
  $('insights-section').classList.add('hidden');
}

/* ══════════════════════════════════════════════════════════════════
   STEP 3 — JOB MATCH
   ══════════════════════════════════════════════════════════════════ */
matchBtn.addEventListener('click', async () => {
  if (!resumeId) return;
  const jobDesc = jobDescInput.value.trim();
  if (!jobDesc) {
    showToast('Please paste a job description first.', 'error');
    return;
  }

  setLoading(matchBtn, true);
  matchResult.classList.add('hidden');

  const form = new FormData();
  form.append('job_description', jobDesc);

  try {
    const res  = await fetch(`${API}/resume/match/${resumeId}`, { method: 'POST', body: form });
    const data = await res.json();

    if (!res.ok) throw new Error(data.detail || 'Match failed');

    renderMatchResult(data);
    showToast(`Match Score: ${data.match_score} — ${data.label}`, 'success');

  } catch (err) {
    showToast(`Match error: ${err.message}`, 'error');
  } finally {
    setLoading(matchBtn, false);
  }
});

function renderMatchResult(data) {
  $('match-score-value').textContent = data.match_score ?? 0;
  $('match-label').textContent       = data.label       ?? '';

  fillList('skills-match-list',    data.skills_match    || []);
  fillList('skills-gap-list',      data.skills_gap      || []);
  fillList('match-suggestions-list', data.suggestions   || []);

  matchResult.classList.remove('hidden');
}

/* ══════════════════════════════════════════════════════════════════
   STEP 4 — REPORT
   ══════════════════════════════════════════════════════════════════ */
reportBtn.addEventListener('click', async () => {
  if (!resumeId) return;

  setLoading(reportBtn, true);
  reportOutput.classList.add('hidden');
  downloadBtn.classList.add('hidden');

  try {
    const res  = await fetch(`${API}/resume/report/${resumeId}`);
    const data = await res.json();

    if (!res.ok) throw new Error(data.detail || 'Could not load report');

    reportData = data;
    reportOutput.textContent = JSON.stringify(data, null, 2);
    reportOutput.classList.remove('hidden');
    downloadBtn.classList.remove('hidden');

    showToast('Report loaded.', 'success');

  } catch (err) {
    showToast(`Report error: ${err.message}`, 'error');
  } finally {
    setLoading(reportBtn, false);
  }
});

downloadBtn.addEventListener('click', () => {
  if (!reportData) return;
  const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `resume_report_${resumeId}.json`;
  a.click();
  URL.revokeObjectURL(url);
});

/* ══════════════════════════════════════════════════════════════════
   HELPERS
   ══════════════════════════════════════════════════════════════════ */

/** Show/hide spinner inside a button */
function setLoading(btn, loading) {
  const text    = btn.querySelector('.btn-text');
  const spinner = btn.querySelector('.btn-spinner');
  btn.disabled  = loading;
  if (loading) {
    text.classList.add('hidden');
    spinner.classList.remove('hidden');
  } else {
    text.classList.remove('hidden');
    spinner.classList.add('hidden');
  }
}

/** Remove the locked state from a section */
function unlock(section) {
  section.classList.add('unlocked');
}

/** Show a toast notification */
let toastTimer = null;
function showToast(message, type = '') {
  toast.textContent = message;
  toast.className   = `toast show ${type}`;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { toast.className = 'toast hidden'; }, 3500);
}

/* ══════════════════════════════════════════════════════════════════
   RESUME HISTORY
   ══════════════════════════════════════════════════════════════════ */

const historyListEl   = $('resume-history-list');
const refreshHistoryBtn = $('refresh-history-btn');

async function loadResumeHistory() {
  if (!historyListEl) return;
  historyListEl.innerHTML = '<p class="history-placeholder">Loading…</p>';

  try {
    const res  = await fetch(`${API}/resume/list`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Could not load resumes');

    renderResumeHistory(data.resumes || []);
    syncActiveResumeFilenameFromList(data.resumes || []);
  } catch (err) {
    historyListEl.innerHTML =
      `<p class="history-placeholder">Could not load history: ${escapeHTML(err.message)}</p>`;
  }
}

function syncActiveResumeFilenameFromList(resumes) {
  if (!resumeId) return;
  const entry = resumes.find(r => r.id === resumeId);
  if (entry?.filename) {
    activeResumeFilename = entry.filename;
    updateDreamBotResumeContext();
  }
}

function updateDreamBotResumeContext() {
  const ctx   = $('chat-resume-context');
  const label = $('chat-resume-label');
  const hint  = $('chat-resume-hint');
  if (!ctx || !label || !hint) return;

  if (resumeId && activeResumeFilename) {
    ctx.classList.add('active');
    ctx.classList.remove('inactive');
    label.textContent = `Linked: ${activeResumeFilename}`;
    hint.textContent = lastChatRagChunks > 0
      ? `RAG active — last reply used ${lastChatRagChunks} resume excerpt(s)`
      : 'RAG ready — relevant resume excerpts are retrieved for each message';
  } else {
    ctx.classList.remove('active');
    ctx.classList.add('inactive');
    label.textContent = 'No resume linked';
    hint.textContent =
      'Upload or select a resume in the Resume tab for personalised advice.';
    lastChatRagChunks = 0;
  }
}

function renderResumeHistory(resumes) {
  if (!resumes.length) {
    historyListEl.innerHTML =
      '<p class="history-placeholder">No resumes yet. Upload one below to get started.</p>';
    return;
  }

  historyListEl.innerHTML = '';
  resumes.forEach(entry => {
    const id       = entry.id;
    const filename = entry.filename || 'Untitled';
    const status   = entry.status   || 'unknown';
    const score    = entry.score;
    const uploaded = formatUploadedAt(entry.uploaded_at);
    const isActive = id === resumeId;

    const row = document.createElement('div');
    row.className = `history-row${isActive ? ' active' : ''}`;
    row.dataset.resumeId = id;

    const scoreBadge = score != null
      ? `<span>Score: <strong>${Math.round(score)}</strong></span>`
      : '';

    row.innerHTML = `
      <div class="history-meta">
        <div class="history-filename">${escapeHTML(filename)}</div>
        <div class="history-sub">
          <span>${uploaded}</span>
          <span class="history-status ${escapeHTML(status)}">${escapeHTML(status)}</span>
          ${scoreBadge}
          <span>ID: ${escapeHTML(id.substring(0, 8))}…</span>
        </div>
      </div>
      <div class="history-actions">
        <button type="button" class="btn btn-primary btn-sm" data-action="use">Use</button>
        ${status === 'done'
          ? '<button type="button" class="btn btn-outline btn-sm" data-action="report">Report</button>'
          : ''}
        <button type="button" class="btn btn-outline btn-sm" data-action="delete">Delete</button>
      </div>`;

    row.querySelector('[data-action="use"]').addEventListener('click', () => {
      selectResumeFromHistory(entry);
    });
    const reportBtn = row.querySelector('[data-action="report"]');
    if (reportBtn) {
      reportBtn.addEventListener('click', () => loadReportForResume(entry));
    }
    row.querySelector('[data-action="delete"]').addEventListener('click', () => {
      deleteResumeFromHistory(id);
    });

    historyListEl.appendChild(row);
  });
}

function formatUploadedAt(iso) {
  if (!iso) return 'Unknown date';
  try {
    const d = new Date(iso);
    return d.toLocaleString(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short',
    });
  } catch {
    return iso;
  }
}

function selectResumeFromHistory(entry) {
  resumeId = entry.id;
  activeResumeFilename = entry.filename || null;
  updateDreamBotResumeContext();
  hideAnalysisResults();
  matchResult.classList.add('hidden');
  reportOutput.classList.add('hidden');
  downloadBtn.classList.add('hidden');
  reportData = null;

  unlock(analyzeSection);
  unlock(matchSection);
  analyzeBtn.disabled = false;
  matchBtn.disabled   = false;

  if (entry.status === 'done') {
    unlock(reportSection);
    reportBtn.disabled = false;
  } else {
    reportSection.classList.remove('unlocked');
    reportBtn.disabled = true;
  }

  loadResumeHistory();
  showToast(`Using "${entry.filename}"`, 'success');
}

async function loadReportForResume(entry) {
  selectResumeFromHistory(entry);
  if (!resumeId) return;

  setLoading(reportBtn, true);
  reportOutput.classList.add('hidden');
  downloadBtn.classList.add('hidden');

  try {
    const res  = await fetch(`${API}/resume/report/${resumeId}`);
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Could not load report');

    reportData = data;
    reportOutput.textContent = JSON.stringify(data, null, 2);
    reportOutput.classList.remove('hidden');
    downloadBtn.classList.remove('hidden');
    reportSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
    showToast('Report loaded.', 'success');
  } catch (err) {
    showToast(`Report error: ${err.message}`, 'error');
  } finally {
    setLoading(reportBtn, false);
  }
}

async function deleteResumeFromHistory(id) {
  if (!confirm('Delete this resume and all related data (vectors, report, file)?')) return;

  try {
    const res  = await fetch(`${API}/resume/${id}`, { method: 'DELETE' });
    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Delete failed');

    if (resumeId === id) {
      resumeId = null;
      activeResumeFilename = null;
      lastChatRagChunks = 0;
      updateDreamBotResumeContext();
      reportData = null;
      hideAnalysisResults();
      matchResult.classList.add('hidden');
      reportOutput.classList.add('hidden');
      downloadBtn.classList.add('hidden');
      analyzeSection.classList.remove('unlocked');
      matchSection.classList.remove('unlocked');
      reportSection.classList.remove('unlocked');
      analyzeBtn.disabled = true;
      matchBtn.disabled   = true;
      reportBtn.disabled  = true;
    }

    showToast('Resume deleted.', 'success');
    loadResumeHistory();
  } catch (err) {
    showToast(`Delete error: ${err.message}`, 'error');
  }
}

if (refreshHistoryBtn) {
  refreshHistoryBtn.addEventListener('click', loadResumeHistory);
}

/* ══════════════════════════════════════════════════════════════════
   INIT
   ══════════════════════════════════════════════════════════════════ */
checkHealth();
setInterval(checkHealth, 30_000);   // re-check every 30 s
loadResumeHistory();


/* ══════════════════════════════════════════════════════════════════
   MODULE SWITCHING
   ══════════════════════════════════════════════════════════════════ */
const moduleBtns   = document.querySelectorAll('.module-btn');
const modulePanels = document.querySelectorAll('.module-panel');
const navLinks     = document.querySelectorAll('.nav-link[data-nav]');
function switchModule(targetModule) {
  // Update module switcher buttons
  moduleBtns.forEach(b => {
    b.classList.toggle('active', b.dataset.module === targetModule);
  });

  // Update nav links
  navLinks.forEach(a => {
    a.classList.toggle('active', a.dataset.nav === targetModule);
  });

  // Switch panels
  modulePanels.forEach(panel => {
    panel.classList.toggle('active', panel.id === `module-${targetModule}`);
  });

  // Scroll to top of main
  window.scrollTo({ top: 0, behavior: 'smooth' });

  if (targetModule === 'chatbot') {
    updateDreamBotResumeContext();
  }
}

moduleBtns.forEach(btn => {
  btn.addEventListener('click', () => {
    if (btn.classList.contains('disabled')) return;
    switchModule(btn.dataset.module);
  });
});

navLinks.forEach(link => {
  link.addEventListener('click', e => {
    e.preventDefault();
    switchModule(link.dataset.nav);
  });
});

/* ══════════════════════════════════════════════════════════════════
   CHATBOT MODULE
   ══════════════════════════════════════════════════════════════════ */
let chatSessionId = '';   // auto-generated on first message

const chatMessages = $('chat-messages');
const chatInput    = $('chat-input');
const sendBtn      = $('send-btn');
const clearChatBtn = $('clear-chat-btn');
const sessionIdDisplay = $('session-id-display');

/* ── Send message ───────────────────────────────────────────────── */
async function sendMessage() {
  const message = chatInput.value.trim();
  if (!message) return;

  // Render user bubble immediately
  appendChatBubble('user', message);
  chatInput.value = '';
  chatInput.style.height = 'auto';

  setLoading(sendBtn, true);
  chatInput.disabled = true;

  try {
    const res = await fetch(`${API}/chatbot/chat`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ session_id: chatSessionId, message }),
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.detail || 'Chat failed');

    // Store session_id
    if (!chatSessionId) {
      chatSessionId = data.session_id;
      sessionIdDisplay.textContent = chatSessionId.substring(0, 8) + '…';
    }

    // Render bot reply
    appendChatBubble('bot', data.reply);

  } catch (err) {
    appendChatBubble('bot', `❌ Error: ${err.message}`);
    showToast(`Chat error: ${err.message}`, 'error');
  } finally {
    setLoading(sendBtn, false);
    chatInput.disabled = false;
    chatInput.focus();
  }
}

/* ── Append chat bubble ─────────────────────────────────────────── */
function appendChatBubble(role, content) {
  const bubble = document.createElement('div');
  bubble.className = `chat-bubble ${role}`;
  bubble.innerHTML = `<div class="bubble-content">${escapeHTML(content)}</div>`;
  chatMessages.appendChild(bubble);
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

function escapeHTML(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

/* ── Clear chat ─────────────────────────────────────────────────── */
async function clearChat() {
  if (!chatSessionId) {
    // No session yet — just clear UI
    chatMessages.innerHTML = `
      <div class="chat-bubble bot">
        <div class="bubble-content">
          👋 Hi! I'm DreamBot. I'm here to help with your career and academic journey.
          Ask me anything — I'm running locally via LLaMA 3.
        </div>
      </div>`;
    return;
  }

  try {
    const res = await fetch(`${API}/chatbot/clear`, {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify({ session_id: chatSessionId }),
    });

    if (!res.ok) throw new Error('Clear failed');

    // Reset UI
    chatSessionId = '';
    sessionIdDisplay.textContent = 'new';
    chatMessages.innerHTML = `
      <div class="chat-bubble bot">
        <div class="bubble-content">
          👋 Chat cleared. What would you like to talk about?
        </div>
      </div>`;
    showToast('Conversation cleared.', 'success');

  } catch (err) {
    showToast(`Clear error: ${err.message}`, 'error');
  }
}

/* ── Event listeners ────────────────────────────────────────────── */
sendBtn.addEventListener('click', sendMessage);

chatInput.addEventListener('keydown', e => {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
});

clearChatBtn.addEventListener('click', clearChat);

// Auto-resize textarea
chatInput.addEventListener('input', () => {
  chatInput.style.height = 'auto';
  chatInput.style.height = chatInput.scrollHeight + 'px';
});


/* ══════════════════════════════════════════════════════════════════
   LEARNING PATH MODULE
   ══════════════════════════════════════════════════════════════════ */

let lpData = null;   // stores last generated learning path

const lpGenerateBtn = $('lp-generate-btn');
const lpResult      = $('lp-result');
const lpDownloadBtn = $('lp-download-btn');

/* ── Generate ───────────────────────────────────────────────────── */
lpGenerateBtn.addEventListener('click', async () => {
  const goal      = $('lp-goal').value.trim();
  const skillsRaw = $('lp-skills').value.trim();
  const education = $('lp-education').value;
  const duration  = parseInt($('lp-duration').value) || 12;

  if (!goal) {
    showToast('Please enter your career goal.', 'error');
    $('lp-goal').focus();
    return;
  }

  // Parse comma-separated skills
  const skills = skillsRaw
    ? skillsRaw.split(',').map(s => s.trim()).filter(Boolean)
    : [];

  setLoading(lpGenerateBtn, true);
  lpResult.classList.add('hidden');

  try {
    const res = await fetch(`${API}/learning-path/generate`, {
      method:  'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        goal,
        current_skills:  skills,
        education_level: education,
        duration_weeks:  duration,
      }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.detail || 'Generation failed');

    lpData = data;
    renderLearningPath(data);
    showToast('Learning path generated!', 'success');

  } catch (err) {
    showToast(`Error: ${err.message}`, 'error');
  } finally {
    setLoading(lpGenerateBtn, false);
  }
});

/* ── Render full learning path ──────────────────────────────────── */
function renderLearningPath(data) {
  // Header
  $('lp-title').textContent        = data.title          || 'Your Learning Path';
  $('lp-goal-display').textContent = data.goal           || '';
  $('lp-weeks-display').textContent= data.total_weeks    || '';

  // Phases timeline
  renderPhases(data.phases || []);

  // Skills gained
  renderChips('lp-skills-gained', data.skills_gained || []);

  // Career outcomes
  renderItems('lp-outcomes', data.career_outcomes || []);

  // Tips
  renderItems('lp-tips', data.tips || []);

  // Show result
  lpResult.classList.remove('hidden');

  // Smooth scroll to result
  setTimeout(() => {
    lpResult.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, 100);
}

/* ── Phases ─────────────────────────────────────────────────────── */
function renderPhases(phases) {
  const container = $('lp-phases');
  container.innerHTML = '';

  if (!phases.length) {
    container.innerHTML = '<p style="color:var(--text-muted)">No phases returned.</p>';
    return;
  }

  phases.forEach(phase => {
    const topics = (phase.topics || [])
      .map(t => `<span class="topic-chip">${escapeHTML(t)}</span>`)
      .join('');

    const resources = (phase.resources || []).map(r => {
      const type = (r.type || 'resource').toLowerCase();
      const url  = r.url && r.url !== '...' ? r.url : '#';
      const link = url !== '#'
        ? `<a href="${escapeHTML(url)}" target="_blank" rel="noopener" class="resource-link">${escapeHTML(r.title || url)}</a>`
        : `<span class="resource-link">${escapeHTML(r.title || 'Resource')}</span>`;
      return `
        <div class="resource-item">
          <span class="resource-type ${escapeHTML(type)}">${escapeHTML(type)}</span>
          ${link}
        </div>`;
    }).join('');

    const milestone = phase.milestone
      ? `<div class="phase-milestone">
           <span class="milestone-icon">🏁</span>
           <span>${escapeHTML(phase.milestone)}</span>
         </div>`
      : '';

    const card = document.createElement('div');
    card.className = 'phase-card';
    card.innerHTML = `
      <div class="phase-dot">${phase.phase || ''}</div>
      <div class="phase-body">
        <div class="phase-header">
          <span class="phase-name">${escapeHTML(phase.name || `Phase ${phase.phase}`)}</span>
          <span class="phase-duration">⏱ ${phase.duration_weeks || '?'} weeks</span>
        </div>
        ${topics  ? `<div class="phase-topics">${topics}</div>`        : ''}
        ${resources ? `<div class="phase-resources">${resources}</div>` : ''}
        ${milestone}
      </div>`;
    container.appendChild(card);
  });
}

/* ── Chips list (skills) ────────────────────────────────────────── */
function renderChips(id, items) {
  const ul = $(id);
  ul.innerHTML = '';
  if (!items.length) {
    ul.innerHTML = '<li>None listed</li>';
    return;
  }
  items.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    ul.appendChild(li);
  });
}

/* ── Plain list (outcomes, tips) ────────────────────────────────── */
function renderItems(id, items) {
  const ul = $(id);
  ul.innerHTML = '';
  if (!items.length) {
    ul.innerHTML = '<li>None listed</li>';
    return;
  }
  items.forEach(item => {
    const li = document.createElement('li');
    li.textContent = item;
    ul.appendChild(li);
  });
}

/* ── Download ───────────────────────────────────────────────────── */
lpDownloadBtn.addEventListener('click', () => {
  if (!lpData) return;
  const blob = new Blob(
    [JSON.stringify(lpData, null, 2)],
    { type: 'application/json' }
  );
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = `learning_path_${Date.now()}.json`;
  a.click();
  URL.revokeObjectURL(url);
});
